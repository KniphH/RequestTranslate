









import { readClipboardImage, errText } from './lib/clipboard-read.js';

const TARGET = 'rt-offscreen';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.target !== TARGET) return false;

  if (msg.type === 'read-image') {
    readClipboardImage(document)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, reason: 'unavailable', error: errText(err) }));
    return true; 
  }
  return false;
});
