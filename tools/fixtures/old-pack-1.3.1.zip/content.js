





(() => {
  if (window.__requestTranslateInjected) return;
  window.__requestTranslateInjected = true;

  const HOST_ID = 'request-translate-host';
  if (document.getElementById(HOST_ID)) return;

  

  let prefs = {
    trigger: 'button',
    triggerStyle: 'badge',
    triggerSize: 45,
    triggerSvg: '',
    triggerIdleSec: 5,
    triggerLeaveSec: 0.5,
    panelWidth: 460,
    panelHeight: 0,
    panelMaxHeight: 46,
    fontSize: 20,
    theme: 'auto',
    showOriginal: true,
    
    targetLang: '简体中文',
    maxChars: 8000
  };
  let configs = [];
  let activeConfigId = '';
  let currentText = '';
  let currentConfigId = '';
  let busy = false;
  let lastAuto = { text: '', at: 0 };

  










  const resultCache = new Map();   
  let cacheKey = null;
  
  let pendingConfigId = '';

  








  
  let imageConfigs = [];
  
  let imageConfigId = '';
  
  let cfgMode = 'text';

  
  let zoom = 1;
  
  let lastAnchor = null;
  


  let lastMouse = null;
  
  let lastRightClick = null;
  


  let lastFrameSel = null;
  
  let lastOcr = null;
  
  let lastAction = '';
  
  let lastOcrAnchor = null;

  
  



  const TRIGGER_CSS = window.RTPanelCore.TRIGGER_CSS;

  

  function T(key, fallback) {
    const api = window.RTI18n;
    if (api && typeof api.t === "function") {
      const got = api.t(key);
      if (got && got !== key) return got;
    }
    return fallback;
  }

  


  const SVG_GUARDS = [
    { re: /^<svg[\s>]/i, negate: true, reason: '要以 <svg 开头' },
    { re: /<\/svg>\s*$/i, negate: true, reason: '要以 </svg> 结尾' },
    {
      re: /<\s*(?:script|foreignObject|iframe|image|use|a|style|animate|set)\b/i,
      reason: '不能有 <script> / <foreignObject> / <use> / <image> / <a> / <style> 这类标签'
    },
    { re: /\son[a-z]+\s*=/i, reason: '不能带 onload / onclick 这类事件属性' },
    { re: /\b(?:xlink:)?href\s*=/i, reason: '不能带 href 外链' }
  ];

  
  function sanitizeTriggerSvg(input) {
    const raw = String(input || '').trim();
    if (!raw) return '';
    for (const g of SVG_GUARDS) {
      const hit = g.re.test(raw);
      if (g.negate ? !hit : hit) return '';
    }
    return raw;
  }

  const TRIGGER_PRESETS = {
    badge: { round: true, html: '译' },
    globe: {
      round: false,
      html: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.6"/><ellipse cx="12" cy="12" rx="3.9" ry="8.6"/><path d="M3.6 9.1h16.8M3.6 14.9h16.8"/></svg>'
    },
    
    
    
    custom: {
      round: false,
      html: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
  <path d="M3.5 7.5h11M3.5 12h7.5M3.5 16.5h9"/>
  <path d="M14.5 9.5 18 13l-3.5 3.5"/>
  <path d="M18 13h-6.5"/>
</svg>`
    }
  };

  

  const host = document.createElement('div');
  host.id = HOST_ID;
  host.style.cssText = [
    'position:fixed',
    'top:0',
    'left:0',
    'width:0',
    'height:0',
    'z-index:2147483647',
    'pointer-events:none'
  ].join(';');

  const shadow = host.attachShadow({ mode: 'open' });

  const style = document.createElement('style');
  


  style.textContent = window.RTPanelCore.PANEL_CSS;
  shadow.appendChild(style);

  

  const trigger = document.createElement('div');
  trigger.className = 'rt-trigger s-badge';
  trigger.title = T('trigger_translate', '翻译选中内容');
  const triggerIcon = document.createElement('span');
  triggerIcon.className = 'rt-ico';
  triggerIcon.textContent = TRIGGER_PRESETS.badge.html;
  trigger.appendChild(triggerIcon);

  const panel = document.createElement('div');
  panel.className = 'rt-panel';
  



  panel.id = 'rt-panel';
  panel.innerHTML = RTPanelCore.shellHtml();   

  shadow.appendChild(trigger);
  shadow.appendChild(panel);

  const dot = panel.querySelector('.rt-dot');
  const cfgSelect = panel.querySelector('.rt-cfg');
  const langSelect = panel.querySelector('.rt-lang');
  const srcBox = panel.querySelector('.rt-src');
  const outBox = panel.querySelector('.rt-out');
  const msgBox = panel.querySelector('.rt-msg');
  const moreBtn = panel.querySelector('.rt-more');
  const diagBox = panel.querySelector('.rt-diag');
  const srcBtn = panel.querySelector('[data-act="src"]');
  








  function refreshShellText() {
    const srcT = panel.querySelector('[data-act="src"]');
    const closeT = panel.querySelector('[data-act="close"]');
    if (srcT) srcT.title = T('panel_src_toggle', '显示 / 隐藏原文');
    if (closeT) closeT.title = T('panel_close', '关闭 (Esc)');
    if (moreBtn) moreBtn.title = T('panel_more_title', '查看详细信息');
    const out = panel.querySelector('.rt-out');
    
    if (out && out.classList.contains('empty')) {
      out.dataset.placeholder = T('panel_waiting', '等待结果…');
    }
    if (trigger) trigger.title = T('trigger_translate', '翻译选中内容');
  }

  

  function mount() {
    if (!document.documentElement.contains(host)) document.documentElement.appendChild(host);
  }

  

  const lightQuery = window.matchMedia
    ? window.matchMedia('(prefers-color-scheme: light)')
    : null;

  function resolveDark() {
    const t = prefs.theme || 'auto';
    if (t === 'light') return false;
    if (t === 'dark') return true;
    return lightQuery ? !lightQuery.matches : true;
  }

  function applyTheme() {
    const light = !resolveDark();
    panel.classList.toggle('light', light);
    panel.dataset.rtTheme = light ? 'light' : 'dark';
    
    trigger.classList.toggle('light', light);
  }

  function applyFontSize() {
    const fs = Math.min(48, Math.max(11, Number(prefs.fontSize) || 20));
    panel.style.setProperty('--rt-fs', fs + 'px');
    panel.style.setProperty('--rt-fs-sm', (fs * 0.92).toFixed(2) + 'px');
    panel.style.setProperty('--rt-fs-xs', (fs * 0.85).toFixed(2) + 'px');
  }

  function panelWidth() {
    return Math.min(1600, Math.max(280, Number(prefs.panelWidth) || 460));
  }

  
  function panelMaxHeight() {
    const v = Number(prefs.panelMaxHeight);
    return Number.isFinite(v) ? Math.min(100, Math.max(0, v)) : 46;
  }

  function applyPanelSize() {
    panel.style.width = panelWidth() + 'px';

    const h = Number(prefs.panelHeight) || 0;
    if (h > 0) {
      panel.style.maxHeight = Math.min(2400, Math.max(200, h)) + 'px';
      panel.classList.add('fixed-h');
    } else {
      panel.style.maxHeight = '';
      panel.classList.remove('fixed-h');
    }

    
    const mh = panelMaxHeight();
    panel.classList.toggle('no-max-h', mh === 0);
    panel.style.setProperty('--rt-max-h', mh + 'vh');
  }

  
  




  
  function triggerSize() {
    return Math.min(96, Math.max(20, Math.round(Number(prefs.triggerSize) || 45)));
  }

  
  function triggerPreset() {
    return TRIGGER_PRESETS[prefs.triggerStyle] || TRIGGER_PRESETS.badge;
  }

  
  function applyTriggerStyle() {
    const id = TRIGGER_PRESETS[prefs.triggerStyle] ? prefs.triggerStyle : 'badge';
    for (const key of Object.keys(TRIGGER_PRESETS)) trigger.classList.toggle('s-' + key, key === id);
    
    const markup = sanitizeTriggerSvg(prefs.triggerSvg) || TRIGGER_PRESETS[id].html;
    
    
    if (triggerIcon.__markup !== markup) {
      triggerIcon.innerHTML = markup;
      triggerIcon.__markup = markup;
    }
    applyZoom();
  }

  







  let userCssEl = null;
  function applyUserCss(css) {
    const text = String(css == null ? '' : css);
    if (!text.trim()) {
      if (userCssEl) {
        userCssEl.remove();
        userCssEl = null;
      }
      return;
    }
    if (!userCssEl) {
      userCssEl = document.createElement('style');
      userCssEl.id = 'rt-user-css';
      shadow.appendChild(userCssEl);
    }
    userCssEl.textContent = text;
  }

  function applyAppearance() {
    applyTheme();
    applyFontSize();
    applyPanelSize();
    applyTriggerStyle();
    applyUserCss(prefs.panelCss);
  }

  function applyZoom() {
    const k = 1 / zoom;
    const size = triggerSize();

    panel.style.setProperty('--rt-zs', String(k));
    panel.style.setProperty('--rt-zoom', String(zoom));

    
    
    
    
    trigger.style.setProperty('--rt-tr-size', (size * k).toFixed(2) + 'px');
    trigger.style.setProperty(
      '--rt-tr-radius',
      triggerPreset().round ? (size * 0.29 * k).toFixed(2) + 'px' : '50%'
    );
    trigger.style.setProperty('--rt-tr-font', (size * 0.47 * k).toFixed(2) + 'px');
  }

  

  function copyRect(r) {
    if (!r) return null;
    return {
      left: r.left, right: r.right, top: r.top, bottom: r.bottom,
      width: r.width, height: r.height
    };
  }

  function setZoom(next) {
    const z = Math.min(5, Math.max(0.25, Number(next) || 1));
    if (Math.abs(z - zoom) < 0.001) return;
    zoom = z;
    applyZoom();

    



    if (panel.classList.contains('show')) placePanel(lastAnchor);
    if (trigger.classList.contains('show')) updateTrigger();
  }

  async function syncZoom() {
    try {
      const z = await chrome.runtime.sendMessage({ type: 'rt-get-zoom' });
      if (typeof z === 'number') setZoom(z);
    } catch {
      
    }
  }

  if (lightQuery) {
    const onSchemeChange = () => {
      if ((prefs.theme || 'auto') === 'auto') applyTheme();
    };
    lightQuery.addEventListener('change', onSchemeChange);
  }

  

  
  const EDGE = 12;

  

  const MOUSE_GAP = 14;

  







  function clampPanel(x, y) {
    const k = 1 / zoom;
    const edge = EDGE * k;
    const wVis = panel.offsetWidth * k;
    const hVis = panel.offsetHeight * k;
    const maxX = window.innerWidth - wVis - edge;
    const maxY = window.innerHeight - hVis - edge;

    return {
      x: maxX <= edge ? edge : Math.min(Math.max(x, edge), maxX),
      y: maxY <= edge ? edge : Math.min(Math.max(y, edge), maxY)
    };
  }

  function placePanel(anchor) {
    applyPanelSize();
    
    if (anchor) lastAnchor = copyRect(anchor);

    const k = 1 / zoom;
    const w = panelWidth();
    const rw = w * k;          
    const gap = 14 * k;        
    const edge = EDGE * k;
    const vw = window.innerWidth;

    
    let x = anchor ? anchor.right + gap : vw - rw - edge;
    const y = anchor ? anchor.bottom + 10 * k : 80 * k;
    if (anchor && x + rw > vw - edge) x = anchor.left - rw - gap;

    const p = clampPanel(x, y);
    panel.style.left = p.x + 'px';
    panel.style.top = p.y + 'px';
  }

  



  function keepPanelInView() {
    if (!panel.classList.contains('show')) return;
    const x = parseFloat(panel.style.left) || 0;
    const y = parseFloat(panel.style.top) || 0;
    const p = clampPanel(x, y);
    if (p.x !== x) panel.style.left = p.x + 'px';
    if (p.y !== y) panel.style.top = p.y + 'px';
  }

  










  const panelResizeObs = new ResizeObserver(() => {
    keepPanelInView();
  });

  

  function showPanel(anchor) {
    panelResizeObs.observe(panel);   

    mount();
    
    
    panel.classList.add('show');
    placePanel(anchor);
    keepPanelInView();
  }

  function hidePanel() {
    panel.classList.remove('show');
    

    if (port) {
      try {
        port.postMessage({ type: 'abort' });
      } catch {
        
      }
    }
  }

  



  let trigIdleTimer = null;
  let trigLeaveTimer = null;
  
  let trigHovered = false;
  
  let trigShownAt = 0;

  function clearTriggerTimers() {
    if (trigIdleTimer) { clearTimeout(trigIdleTimer); trigIdleTimer = null; }
    if (trigLeaveTimer) { clearTimeout(trigLeaveTimer); trigLeaveTimer = null; }
  }

  


  function armTriggerIdle() {
    clearTriggerTimers();
    const sec = Number(prefs.triggerIdleSec) || 0;
    trigIdleTimer = sec > 0 ? setTimeout(hideTrigger, sec * 1000) : null;
  }

  
  function armTriggerLeave() {
    clearTriggerTimers();
    const sec = Number(prefs.triggerLeaveSec) || 0;
    if (sec > 0) trigLeaveTimer = setTimeout(hideTrigger, sec * 1000);
    else armTriggerIdle();
  }

  function hideTrigger() {
    clearTriggerTimers();
    trigHovered = false;
    trigger.classList.remove('show');
  }

  function setStatus(text, kind) {
    msgBox.textContent = text || '';
    msgBox.className = 'rt-msg' + (kind ? ' ' + kind : '');
  }

  
  
  const dotTip = (kind) => {
    if (kind === 'on') return T('trigger_dot_on', '正在翻译…');
    if (kind === 'ok') return T('trigger_dot_ok', '翻译成功');
    return T('trigger_dot_err', '翻译失败');
  };

  function setDot(kind) {
    dot.className = 'rt-dot' + (kind ? ' ' + kind : '');
    dot.title = dotTip(kind);
  }

  




  










  function enterBusy(placeholder, statusText, opts = {}) {
    if (opts.cancelDelta) cancelPendingDelta();
    busy = true;
    
    outBox.classList.remove('empty');
    


    if (slots.length <= 1) {
      outBox.textContent = '';
      outBox.dataset.placeholder = placeholder;
    }
    if (opts.clearSrc) {
      srcBox.textContent = '';
      srcBox.classList.remove('has-img');
    }
    resetDiag();
    setStatus(statusText, opts.statusKind || '');
    setDot('on');
  }

  



  function leaveBusy() {
    cancelPendingDelta();
    busy = false;
  }

  










  function showFailure(why, opts = {}) {
    leaveBusy();
    outBox.classList.remove('empty');
    outBox.dataset.placeholder = opts.placeholder || T('panel_error_fallback', '出错了');
    



    const only = slots[0];
    if (only) {
      only.state = 'fail';
      only.error = why;
      renderSlots();
    } else {
      outBox.textContent = '';
    }
    setStatus(why, 'err');
    setDot('err');
    showDiag(opts.diag || [{ k: opts.diagKey || '错误', v: why, err: true }]);
  }

  

  function syncSrcBtn() {
    const on = !!prefs.showOriginal;
    srcBox.classList.toggle('hidden', !on);
    srcBtn.classList.toggle('on', on);
    srcBtn.title = T(on ? 'panel_src_showing' : 'panel_src_hidden', on ? '隐藏原文（当前显示中）' : '显示原文（当前隐藏中）');
  }

  



  let saveChain = Promise.resolve();

  function mutateState(mutate) {
    saveChain = saveChain.then(async () => {
      try {
        const raw = await chrome.storage.local.get('state');
        const st = raw && raw.state;
        if (!st || mutate(st) === false) return;
        await chrome.storage.local.set({ state: st });
      } catch {
        
      }
    });
    return saveChain;
  }

  
  function saveSetting(key, value) {
    return mutateState((st) => {
      st.settings = { ...(st.settings || {}), [key]: value };
    });
  }

  


  function saveImageConfigId(id) {
    return mutateState((st) => {
      if (!st.ocr) return false;
      st.ocr.imageConfigId = id;
    });
  }

  

  let diagOpen = false;

  








  function formatBytes(n) {
    const b = Math.max(0, Number(n) || 0);
    if (b < 1024) return b + ' B';
    if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
    return (b / 1024 / 1024).toFixed(1) + ' MB';
  }

  function buildDiag(r) {
    const rows = [];
    const secs = (v) => (typeof v === 'number' ? (v / 1000).toFixed(2) + ' s' : '—');
    
    if (lastOcr) {
      rows.push(lastOcr.direct
        ? {
            k: '截图直传',
            v: '没有走 OCR，图片直接进了请求' + (lastOcr.bytes ? ' · 图 ' + formatBytes(lastOcr.bytes) : ''),
            hint: '设置里勾了「禁用外置 OCR」，这张图是靠 {{image}} 塞进请求模板的'
          }
        : {
            k: '截图 OCR',
            v: `${lastOcr.provider} · ${secs(lastOcr.ms)}` +
              (lastOcr.bytes ? ' · 图 ' + formatBytes(lastOcr.bytes) : ''),
            hint: '这段原文是剪切板里那张截图认出来的'
          });
    }
    rows.push({ k: '首字', v: secs(r.firstDeltaMs), hint: '第一个译文分片出现的时间，你等待的就是它' });
    rows.push({ k: '总耗时', v: secs(r.ms) });
    if (r.mode) rows.push({ k: '响应格式', v: String(r.mode).toUpperCase() });
    if (typeof r.chunks === 'number') rows.push({ k: '分片', v: String(r.chunks) });
    if (r.bytes) rows.push({ k: '响应大小', v: formatBytes(r.bytes) });
    if (r.usedPath) rows.push({ k: '命中路径', v: r.usedPath });
    
    
    if (r.model) rows.push({ k: '模型', v: r.model, hint: '这条请求里写的模型名（读的是请求体 / 地址，不是猜的）' });

    if (r.reasoningChars) {
      rows.push({
        k: '模型思考',
        v: r.reasoningChars + ' 字 —— 思考没关掉，翻译场景把 reasoning_effort 设成 "none" 会快很多',
        warn: true
      });
    } else {
      rows.push({ k: '模型思考', v: '无（直接作答）' });
    }

    if (r.missingVars && r.missingVars.length) {
      rows.push({ k: '缺失变量', v: r.missingVars.join('、'), err: true });
    }
    for (const w of (r.warnings || [])) rows.push({ k: '提示', v: w, warn: true });
    if (r.error) rows.push({ k: '错误', v: r.error, err: true });
    return rows;
  }

  function showDiag(rows) {
    

    RTPanelCore.renderDiag(diagBox, rows);
    const any = rows.length > 0;
    moreBtn.hidden = !any;
    moreBtn.classList.toggle('warn', rows.some((x) => x.warn || x.err));
    diagBox.hidden = !any || !diagOpen;
  }

  function resetDiag() {
    diagOpen = false;
    diagBox.textContent = '';
    diagBox.hidden = true;
    moreBtn.hidden = true;
    moreBtn.classList.remove('warn');
  }

  

  let port = null;

  function connectPort() {
    try {
      port = chrome.runtime.connect({ name: 'rt-translate' });
    } catch {
      port = null;
      return null;
    }
    port.onMessage.addListener(onPortMessage);
    port.onDisconnect.addListener(() => {
      port = null;
      


      if (busy) portGone();
    });
    





    try {
      port.postMessage({ type: 'hello' });
    } catch {
      port = null;
      return null;
    }
    return port;
  }

  function ensurePort() {
    if (!port) connectPort();
    return port;
  }

  

  function postOrFail(p, msg) {
    if (!p) {
      portGone();
      return false;
    }
    







    try {
      p.postMessage(msg);
    } catch {
      portGone();
      return false;
    }
    return true;
  }

  

  




  const RENDER_INTERVAL = 50;

  



  
  let speakingKey = '';

  let pendingDelta = null;
  let deltaTimer = 0;
  let lastFlush = 0;

  function cancelPendingDelta() {
    if (deltaTimer) {
      clearTimeout(deltaTimer);
      deltaTimer = 0;
    }
    pendingDelta = null;
  }

  function applyDelta() {
    deltaTimer = 0;
    lastFlush = performance.now();
    pendingDelta = null;

    


    {
      renderSlots();
    }
    
    keepPanelInView();
  }

  










  function queueDelta() {
    if (deltaTimer) return;
    const gap = performance.now() - lastFlush;
    if (gap >= RENDER_INTERVAL) applyDelta();
    else deltaTimer = setTimeout(applyDelta, RENDER_INTERVAL - gap);
  }

  

  






  function renderResult(r, ocr, action, fatal) {
    leaveBusy();
    
    lastOcr = ocr || null;
    if (action) lastAction = action;

    if (r && r.text) {
      outBox.classList.remove('empty');
      


      const only = slots[0];
      if (only) {
        only.state = 'done';
        only.text = r.text;
        only.error = '';
        renderSlots();
      } else {
        outBox.textContent = r.text;
      }
      
      const bits = [];
      if (lastOcr) bits.push(lastOcr.direct ? '截图直传' : '截图 OCR');
      if (r.status) bits.push('HTTP ' + r.status);
      if (typeof r.ms === 'number') bits.push((r.ms / 1000).toFixed(1) + 's');
      if (r.usedPath) bits.push(r.usedPath);
      const noisy = (r.warnings && r.warnings.length > 0) ||
        (r.missingVars && r.missingVars.length > 0);
      setStatus(bits.join(' · '), noisy ? 'warn' : '');
      setDot('ok');
      showDiag(buildDiag(r));
      return;
    }

    const why = (r && r.error) || (fatal ? '出错了' : '没有拿到译文');
    showFailure(why, fatal
      ? {}
      : { placeholder: '没有返回内容', diag: buildDiag(r || {}) });
  }

  
  function rememberResult(configId, r, ocr, action, fatal) {
    if (!configId) return;
    resultCache.set(configId, { r, ocr, action, fatal: !!fatal });
  }

  

  function showNoCachedResult(configId) {
    const hit = configs.find((c) => c.id === configId);
    leaveBusy();
    resetDiag();
    outBox.classList.remove('empty');
    outBox.textContent = '';
    outBox.dataset.placeholder = '点 ↻ 翻译';
    setDot('');
    setStatus(hit ? `已切到「${hit.name}」，点 ↻ 翻译` : '点 ↻ 翻译');
  }

  


  function applyConfigList(list) {
    configs = (list || []).map((c) => ({ id: c.id, name: c.name, img: !!c.img }));
    imageConfigs = configs.filter((c) => c.img).map((c) => ({ id: c.id, name: c.name }));
  }

  function onPortMessage(msg) {
    if (!msg) return;

    if (msg.type === 'ready') {
      applyConfigList(msg.configs);
      if (typeof msg.imageConfigId === 'string') imageConfigId = msg.imageConfigId;
      if (Array.isArray(msg.targetLangs)) targetLangs = msg.targetLangs;
      activeConfigId = msg.activeConfigId || (configs[0] && configs[0].id) || '';
      if (msg.settings) prefs = { ...prefs, ...msg.settings };
      renderConfigOptions();
      renderLangOptions();
      return;
    }

    if (msg.type === 'start') {
      


      const sl = slotForMsg(msg);
      if (!sl) return;
      sl.state = 'busy';
      sl.statusText = msg.statusText || '';
      cancelPendingDelta();
      
      
      
      if (slots.length <= 1) {
        setStatus(msg.statusText ? `请求中…${msg.statusText}` : '请求中…');
        setDot('on');
        outBox.classList.add('empty');
        outBox.textContent = '';
        resetDiag();
      } else {
        setStatus(`翻译中…（${slots.length} 条）`);
        setDot('on');
        renderSlots();
      }
      return;
    }

    if (msg.type === 'delta') {
      
      const sl = slotForMsg(msg);
      if (!sl) return;
      sl.state = 'busy';
      sl.text = msg.text || '';
      queueDelta();
      return;
    }

    

    if (msg.type === 'ocr-status') {
      setStatus(msg.message || '处理中…');
      return;
    }

    if (msg.type === 'ocr-error') {
      showFailure(msg.message || '截图识别失败', { diagKey: '截图 OCR' });
      return;
    }

    if (msg.type === 'ocr-text') {
      const text = String(msg.text || '').trim();
      if (!text) {
        setStatus('没识别出文字', 'err');
        setDot('err');
        leaveBusy();
        return;
      }
      
      
      
      translate(text, '', {
        provider: msg.provider || 'OCR',
        ms: msg.ms,
        bytes: msg.bytes
      });
      return;
    }

    if (msg.type === 'ocr-image') {
      


      translate('', '', {
        direct: true,
        image: msg.dataUrl,
        bytes: msg.bytes
      });
      return;
    }

    if (msg.type === 'done') {
      const r = msg.result || {};
      const sl = slotForMsg(msg);
      
      rememberResult(msg.configId || pendingConfigId, r, lastOcr, lastAction, false);
      if (!sl) {
        
        leaveBusy();
        return;
      }
      sl.result = r;
      sl.state = r && r.text ? 'done' : 'fail';
      sl.text = r.text || sl.text;
      sl.error = (r && r.error) || '';
      
      
      cancelPendingDelta();
      if (slots.length <= 1) {
        renderResult(r, lastOcr, lastAction, false);
      } else {
        renderSlots();
        if (allSettled()) {
          leaveBusy();
          const okCount = slots.filter((s2) => s2.state === 'done').length;
          setDot(okCount ? 'ok' : 'err');
          setStatus(settledSummary(), okCount ? '' : 'err');
        }
      }
      return;
    }

    if (msg.type === 'fatal') {
      const r = { error: msg.message || '出错了' };
      const sl = slotForMsg(msg);
      rememberResult(msg.configId || pendingConfigId, r, lastOcr, lastAction, true);
      if (!sl) {
        leaveBusy();
        return;
      }
      sl.result = r;
      sl.state = 'fail';
      sl.error = r.error;
      cancelPendingDelta();
      if (slots.length <= 1) {
        renderResult(r, lastOcr, lastAction, true);
      } else {
        renderSlots();
        if (allSettled()) {
          leaveBusy();
          setDot('err');
          setStatus(settledSummary(), 'err');
        }
      }
    }
  }

  



  function imageCapable(c) {
    if (!c) return false;
    


    const on = [
      ...(c.mainEnabled !== false ? [c] : []),
      ...(Array.isArray(c.fallbacks) ? c.fallbacks.filter((f) => f.enabled !== false) : [])
    ];
    
    if (!on.length && c) on.push(c);
    return on.some((r) => !!String(r.imageRequest || '').trim());
  }

  


  function shownConfigId() {
    return cfgMode === 'image' && imageConfigs.length > 0 ? imageConfigId : currentConfigId;
  }

  







  let slots = [];

  const slotLimit = () => Math.max(1, Math.min(4, Number(prefs.panelSlots) || 1));

  



  const slotPool = () => (cfgMode === 'image' && imageConfigs.length > 0 ? imageConfigs : configs);
  const slotsKey = () => (cfgMode === 'image' ? 'imageSlotConfigs' : 'slotConfigs');

  



  const slotsByMode = { text: [], image: [] };
  function switchSlotMode(nextMode) {
    if (cfgMode === nextMode) return;
    slotsByMode[cfgMode] = slots;
    slots = slotsByMode[nextMode] || [];
    cfgMode = nextMode;
  }

  function slotBy(configId) {
    return slots.find((s) => s.configId === configId) || null;
  }

  






  function slotForMsg(msg) {
    return msg && msg.configId ? slotBy(msg.configId) : slots[0] || null;
  }

  function makeSlot(configId) {
    const c = configs.find((x) => x.id === configId);
    return {
      configId,
      name: c ? c.name : configId,
      state: 'idle',      
      text: '',
      error: '',
      statusText: ''
    };
  }

  










  function initSlots() {
    const pool = slotPool();
    const ids = pool.map((c) => c.id);
    
    const kept = slots
      .filter((s) => ids.includes(s.configId))
      .map((s) => ({ ...s, name: (pool.find((c) => c.id === s.configId) || {}).name || s.name }));
    if (kept.length) {
      slots = kept;
      return;
    }
    const saved = Array.isArray(prefs[slotsKey()]) ? prefs[slotsKey()] : [];
    const want = saved.filter((id) => ids.includes(id));
    
    const ordered = pool.filter((c) => want.includes(c.id)).map((c) => c.id);
    




    


    const primary = cfgMode === 'image' ? (imageConfigId || activeConfigId) : activeConfigId;
    let seeded;
    if (ordered.length) {
      seeded = ordered.slice(0, slotLimit());
    } else {
      seeded = ids.includes(primary) ? [primary] : (ids[0] ? [ids[0]] : []);
    }
    slots = seeded.map(makeSlot);
  }

  





  function persistSlots() {
    prefs[slotsKey()] = slots.filter((s) => !s.temp).map((s) => s.configId).slice(0, slotLimit());
  }

  
  function removeSlot(configId) {
    if (slots.length <= 1) return;
    slots = slots.filter((s) => s.configId !== configId);
    



    if (currentConfigId === configId) {
      currentConfigId = slots[0] ? slots[0].configId : '';
    }
    persistSlots();
  }

  const allSettled = () => slots.every((s) => s.state === 'done' || s.state === 'fail');

  
  function settledSummary() {
    const ok = slots.filter((s) => s.state === 'done').length;
    const bad = slots.filter((s) => s.state === 'fail').length;
    if (!bad) return `${ok} 条都拿到了译文`;
    if (!ok) return `${bad} 条都失败了`;
    return `${ok} 条拿到译文，${bad} 条失败`;
  }

  






  














  function renderSlots() {
    if (!slots.length) return;
    outBox.classList.remove('empty');
    const keepTop = outBox.scrollTop;

    

    const kids = outBox.children;
    let reusable = kids.length === slots.length;
    if (reusable) {
      for (let i = 0; i < slots.length; i += 1) {
        if (kids[i].getAttribute('data-cid') !== slots[i].configId) { reusable = false; break; }
      }
    }

    if (!reusable) {
      
      outBox.innerHTML = RTPanelCore.slotsHtml(slots, { speaking: speakingKey });
    } else {
      for (let i = 0; i < slots.length; i += 1) {
        RTPanelCore.patchSlot(kids[i], slots[i], speakingKey === slots[i].configId);
      }
    }

    if (keepTop) outBox.scrollTop = keepTop;
    keepPanelInView();
  }

  

  





  function renderSlotResult(configId, r, ocr, action, fatal) {
    const sl = slotBy(configId);
    if (sl) {
      sl.result = r;
      sl.state = fatal ? 'fail' : (r && r.text ? 'done' : 'fail');
      sl.text = (r && r.text) || sl.text || '';
      sl.error = (r && r.error) || '';
    }
    
    renderResult(r, ocr, action, fatal);
  }



  

  

  




  function renderConfigOptions() {
    const imgMode = cfgMode === 'image' && imageConfigs.length > 0;
    const list = imgMode ? imageConfigs : configs;

    cfgSelect.innerHTML = '';
    if (!list.length) {
      const o = document.createElement('option');
      o.textContent = T('panel_no_config', '（没有配置）');
      o.value = '';
      cfgSelect.appendChild(o);
      cfgSelect.title = T('panel_cfg_only', '翻译接口');
      return;
    }
    for (const c of list) {
      const o = document.createElement('option');
      o.value = c.id;
      o.textContent = c.name;
      cfgSelect.appendChild(o);
    }

    
    let want = imgMode ? imageConfigId : currentConfigId;
    if (!list.some((c) => c.id === want)) {
      want = imgMode
        ? list[0].id
        : (activeConfigId && list.some((c) => c.id === activeConfigId) ? activeConfigId : list[0].id);
    }
    
    


    if (imgMode) imageConfigId = want;
    else currentConfigId = want;
    initSlots();

    cfgSelect.value = want;

    
    
    const cur = list.find((c) => c.id === want);
    const who = cur ? cur.name : '';
    const extra = !imgMode && slots.length > 1
      ? T('panel_compare_note', '（对比中：共 $1$ 条）').replace('$1$', String(slots.length))
      : '';
    if (cfgMode !== 'image') {
      cfgSelect.title = cur
        ? T('panel_cfg_with', '翻译接口：$1$').replace('$1$', who + extra)
        : T('panel_cfg_only', '翻译接口');
    } else if (imageConfigs.length) {
      cfgSelect.title = T('panel_img_cfg_with', '图片接口：$1$').replace('$1$', who);
    } else {
      cfgSelect.title = T('panel_img_none',
        '还没有任何配置填过「图片请求模板」——去设置页的「配置」栏给能看图的那条填上，' +
        '它才会出现在这个列表里。现在用的是「$1$」').replace('$1$', who);
    }
  }

  


  function afterSlotChange() {
    renderConfigOptions();
    if (!panel.classList.contains('show')) return;
    lastOcr = null;
    lastAction = 'translate';
    if (!currentText) {
      showNoCachedResult(slots[0] ? slots[0].configId : shownConfigId());
      return;
    }
    const toRun = [];
    for (const sl of slots) {
      const hit = resultCache.get(sl.configId);
      if (hit) {
        sl.state = hit.fatal ? 'fail' : 'done';
        sl.text = (hit.r && hit.r.text) || '';
        sl.error = (hit.r && hit.r.error) || '';
      } else {
        toRun.push(sl.configId);
      }
    }
    if (!toRun.length) {
      
      cancelPendingDelta();
      if (slots.length <= 1) {
        const hit = resultCache.get(slots[0].configId);
        if (hit) renderResult(hit.r, hit.ocr, hit.action, hit.fatal);
      } else {
        renderSlots();
        leaveBusy();
        setDot('ok');
        setStatus(settledSummary());
      }
      keepPanelInView();
      return;
    }
    translate(currentText, '', undefined, { only: toRun });
  }

  

  let targetLangs = [];

  function renderLangOptions() {
    const cur = String(prefs.targetLang || '简体中文');
    
    
    const list = targetLangs.includes(cur) ? targetLangs.slice() : [cur].concat(targetLangs);
    langSelect.innerHTML = '';
    for (const name of list) {
      const o = document.createElement('option');
      o.value = name;
      o.textContent = name;
      langSelect.appendChild(o);
    }
    langSelect.value = cur;
    langSelect.title = T('panel_lang_with', '目标语言：$1$').replace('$1$', cur);
  }

  

  const DIRECT_SRC_NOTE = '（这张截图直接发给了模型，没有先做外置 OCR）';

  




  function renderSrcImage(dataUrl) {
    srcBox.textContent = '';
    srcBox.classList.add('has-img');
    const img = document.createElement('img');
    img.className = 'rt-srcimg';
    img.alt = '截取的图';
    img.addEventListener('error', () => {
      img.remove();
      srcBox.classList.remove('has-img');
      srcBox.textContent = DIRECT_SRC_NOTE;
    });
    img.src = dataUrl;
    const note = document.createElement('div');
    note.textContent = DIRECT_SRC_NOTE;
    srcBox.append(img, note);
  }

  function translate(text, configId, ocr, opts) {
    
    const limit = Math.max(1, Number(prefs.maxChars) || 8000);
    let payload = String(text || '');
    let truncated = false;
    if (payload.length > limit) {
      payload = payload.slice(0, limit);
      truncated = true;
    }
    
    const hasImage = !!(ocr && ocr.image);
    if (!payload.trim() && !hasImage) return;

    
    
    const nextMode = hasImage ? 'image' : 'text';
    if (cfgMode !== nextMode) {
      switchSlotMode(nextMode);
      renderConfigOptions();
    }

    lastOcr = ocr || null;
    
    
    lastAction = ocr ? 'ocr' : 'translate';
    currentText = payload;

    

    if (!configId && !slots.length) initSlots();
    const picked = configId || (slots[0] && slots[0].configId) || currentConfigId || activeConfigId;
    
    
    if (cfgMode === 'image' && imageConfigs.length > 0) imageConfigId = picked;
    else currentConfigId = picked;
    pendingConfigId = picked;

    
    
    const key = hasImage
      ? '\u0001img|' + (ocr.image || '').length + '|' + (ocr.image || '').slice(-64)
      : payload;
    if (key !== cacheKey) {
      cacheKey = key;
      resultCache.clear();
    }

    
    enterBusy(
      '等待结果…',
      hasImage ? '正在看图…' : (truncated ? `内容过长，已截断到 ${limit} 字` : '…'),
      { statusKind: !hasImage && truncated ? 'warn' : '' }
    );

    
    if (hasImage) renderSrcImage(ocr.image);
    else {
      srcBox.classList.remove('has-img');
      srcBox.textContent = payload.length > 400 ? payload.slice(0, 400) + ' …' : payload;
    }
    syncSrcBtn();
    
    
    keepPanelInView();

    



    const targets = (opts && Array.isArray(opts.only) && opts.only.length)
      ? opts.only
      : ((!configId && slots.length > 1)
        ? slots.map((s) => s.configId)
        : [picked]);
    for (const id of targets) {
      const sl = slotBy(id);
      if (sl) {
        sl.state = 'busy';
        

        sl.error = '';
      }
    }
    if (slots.length > 1) renderSlots();

    const p = ensurePort();
    postOrFail(p, {
      type: 'translate',
      text: payload,
      configIds: targets,
      configId: targets[0],
      context: {
        url: location.href,
        title: document.title,
        
        image: hasImage ? ocr.image : ''
      }
    });
  }

  function openWith(text, anchor) {
    showPanel(anchor);
    hideTrigger();
    
    translate(text, '');
  }

  
  function pointRect(x, y) {
    return { left: x, top: y, right: x, bottom: y, width: 0, height: 0 };
  }

  





  function beginOcrPanel(anchor, statusText) {
    mount();
    showPanel(anchor);
    hideTrigger();

    lastAction = 'ocr';
    lastOcrAnchor = anchor || null;
    lastOcr = null;
    currentText = '';
    
    enterBusy('等待识别…', statusText, { cancelDelta: true, clearSrc: true });

    


    if (port) {
      try {
        port.postMessage({ type: 'abort' });
      } catch {
        
      }
    }

    return ensurePort();
  }

  
  function portGone() {
    leaveBusy();
    setStatus('扩展已更新，请刷新页面后重试', 'err');
    setDot('err');
  }

  
  function startOcr(anchor) {
    const p = beginOcrPanel(anchor, '正在读取剪切板…');
    postOrFail(p, { type: 'ocr' });
  }

  





  function retryShot() {
    if (lastOcr && lastOcr.direct && lastOcr.image) {
      translate('', '', { direct: true, image: lastOcr.image, bytes: lastOcr.bytes });
      return;
    }
    const p = beginOcrPanel(lastOcrAnchor, '正在重试…');
    postOrFail(p, { type: 'ocr', reuse: true });
  }

  
  







  let shotHost = null;

  function closeShot() {
    if (shotHost) {
      if (typeof shotHost.__rtFinish === 'function') shotHost.__rtFinish();
      else shotHost.remove();
      shotHost = null;
    }
  }

  function startShot(dataUrl, error) {
    closeShot();

    
    if (error) {
      mount();
      showPanel(null);
      hideTrigger();
      showFailure('截图失败：' + error);
      return;
    }
    if (typeof dataUrl !== 'string' || !dataUrl.startsWith('data:image/')) return;

    




    const SHOT_TIP = '拖动框选要翻译的区域（可滚动页面）· Esc 或右键取消';
    const hostEl = document.createElement('div');
    hostEl.setAttribute('data-rt-shot', '');
    hostEl.style.cssText = 'position:fixed;inset:0;z-index:2147483647;';
    const root = hostEl.attachShadow({ mode: 'open' });
    root.innerHTML = `
<style>
  * { box-sizing: border-box; }
  /* 这层才是**真正接住鼠标**的东西：铺满整屏、透明、可命中。
     不能用 box-shadow 那层当命中面 —— box-shadow 不参与命中测试，
     而且它自己写的是 pointer-events:none（挖洞要求它不能挡住页面）。
     所以「压暗」和「接指针」必须拆成两层。 */
  .veil {
    position: fixed; inset: 0;
    cursor: crosshair;
    background: rgba(0, 0, 0, .45);
  }
  .sel {
    position: fixed; display: none;
    box-shadow: 0 0 0 100000px rgba(0, 0, 0, .45);
    border: 1px solid #a855f7;
    pointer-events: none;
  }
  .tip {
    position: fixed; top: 14px; left: 50%; transform: translateX(-50%);
    background: rgba(15, 15, 17, .92); color: #e8e8ea;
    border: 1px solid #2b2b33; border-radius: 8px;
    padding: 7px 14px; font: 13px/1.4 system-ui, sans-serif;
    pointer-events: none; white-space: nowrap;
  }
</style>
<div class="veil"></div>
<div class="sel"></div>
<div class="tip">${SHOT_TIP}</div>
`;
    const sel = root.querySelector('.sel');

    const finish = () => {
      window.removeEventListener('keydown', onKey, true);
      window.removeEventListener('contextmenu', onCtx, true);
      hostEl.remove();
      if (shotHost === hostEl) shotHost = null;
    };
    hostEl.__rtFinish = finish;

    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        finish();
      }
    };
    
    const onCtx = (e) => {
      e.preventDefault();
      e.stopPropagation();
      finish();
    };
    window.addEventListener('keydown', onKey, true);
    window.addEventListener('contextmenu', onCtx, true);

    const normRect = (a, b) => ({
      left: Math.min(a.x, b.x),
      top: Math.min(a.y, b.y),
      width: Math.abs(a.x - b.x),
      height: Math.abs(a.y - b.y)
    });
    const moveSel = (cur) => {
      const r = normRect(start, cur);
      
      sel.style.left = r.left + 'px';
      sel.style.top = r.top + 'px';
      sel.style.width = Math.min(r.width, window.innerWidth - r.left) + 'px';
      sel.style.height = Math.min(r.height, window.innerHeight - r.top) + 'px';
    };

    let start = null;

    




    hostEl.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      start = { x: e.clientX, y: e.clientY };
      sel.style.display = 'block';
      moveSel({ x: start.x, y: start.y });
      
      try { hostEl.setPointerCapture(e.pointerId); } catch {  }
      e.preventDefault();
      e.stopPropagation();
    });
    hostEl.addEventListener('pointermove', (e) => {
      if (start) moveSel({ x: e.clientX, y: e.clientY });
    });
    hostEl.addEventListener('pointerup', (e) => {
      if (!start || e.button !== 0) return;
      const rect = normRect(start, { x: e.clientX, y: e.clientY });
      start = null;
      try { hostEl.releasePointerCapture(e.pointerId); } catch {  }
      
      if (rect.width < 4 || rect.height < 4) {
        finish();
        return;
      }
      
      const anchorRect = {
        left: rect.left,
        top: rect.top,
        right: rect.left + rect.width,
        bottom: rect.top + rect.height,
        width: rect.width,
        height: rect.height
      };
      finish();

      cropShot(dataUrl, rect).then((cropped) => {
        if (!cropped) {
          


          const p = beginOcrPanel(anchorRect, '截图失败');
          
          if (p) showFailure('裁图失败');
          else portGone();
          return;
        }
        postOrFail(beginOcrPanel(anchorRect, '正在识别截图…'), { type: 'ocr', dataUrl: cropped });
      });
    });

    (document.documentElement || document.body).appendChild(hostEl);
    shotHost = hostEl;
  }

  



  function cropShot(dataUrl, rect) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        const dpr = img.naturalWidth / Math.max(1, window.innerWidth) || 1;
        const cutX = Math.max(0, Math.round((window.innerWidth - document.documentElement.clientWidth) * dpr));
        const cutY = Math.max(0, Math.round((window.innerHeight - document.documentElement.clientHeight) * dpr));
        const srcW = Math.max(1, img.naturalWidth - cutX);
        const srcH = Math.max(1, img.naturalHeight - cutY);
        const viewW = Math.max(1, document.documentElement.clientWidth);
        const viewH = Math.max(1, document.documentElement.clientHeight);
        const kx = srcW / viewW;
        const ky = srcH / viewH;
        const sx = Math.max(0, Math.min(Math.round(rect.left * kx), srcW - 1));
        const sy = Math.max(0, Math.min(Math.round(rect.top * ky), srcH - 1));
        const sw = Math.max(1, Math.min(Math.round(rect.width * kx), srcW - sx));
        const sh = Math.max(1, Math.min(Math.round(rect.height * ky), srcH - sy));
        const cvs = document.createElement('canvas');
        cvs.width = sw;
        cvs.height = sh;
        try {
          cvs.getContext('2d').drawImage(img, sx, sy, sw, sh, 0, 0, sw, sh);
          resolve(cvs.toDataURL('image/png'));
        } catch {
          resolve(null);
        }
      };
      img.onerror = () => resolve(null);
      img.src = dataUrl;
    });
  }

  

  

  





  function caretRect(sel) {
    if (!sel || !sel.rangeCount || !sel.focusNode) return null;
    try {
      const r = document.createRange();
      r.setStart(sel.focusNode, sel.focusOffset);
      r.collapse(true);
      const b = r.getBoundingClientRect();
      
      if (!b || (b.width === 0 && b.height === 0)) return null;
      return b;
    } catch {
      return null;
    }
  }

  function readSelection() {
    const sel = window.getSelection();
    if (!sel || sel.rangeCount === 0) return null;
    
    
    
    const text = sel.toString().trim();
    if (!text || text.length < 1) return null;
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    if (lastMouse) {
      let panelRect = null;
      try {
        const segs = Array.from(sel.getRangeAt(0).getClientRects()).filter(
          (r) => r.width > 0 || r.height > 0
        );
        if (segs.length) {
          const tail = segs[segs.length - 1];
          panelRect = { left: tail.left, top: tail.top, right: tail.right, bottom: tail.bottom };
        }
      } catch {
        
      }
      return { text, atMouse: true, anchor: { rect: pointRect(lastMouse.x, lastMouse.y) }, panelRect };
    }

    let rect;
    let segments;
    try {
      const range = sel.getRangeAt(0);
      rect = range.getBoundingClientRect();
      segments = Array.from(range.getClientRects()).filter((r) => r.width > 0 || r.height > 0);
    } catch {
      return null;
    }

    
    
    if (!rect || (rect.width === 0 && rect.height === 0)) return null;

    
    const care = caretRect(sel);
    if (care) return { text, anchor: { rect: care } };

    
    const tail = segments.length ? segments[segments.length - 1] : rect;
    return { text, anchor: { rect: tail } };
  }

  function updateTrigger() {
    if (prefs.trigger === 'off') {
      hideTrigger();
      return;
    }
    
    const found = readSelection() || lastFrameSel;
    if (!found) {
      hideTrigger();
      return;
    }

    if (prefs.trigger === 'auto') {
      hideTrigger();
      
      const now = Date.now();
      if (lastAuto.text === found.text && now - lastAuto.at < 900) return;
      lastAuto = { text: found.text, at: now };
      
      openWith(found.text, found.panelRect || found.anchor.rect);
      return;
    }

    mount();
    
    
    
    applyTriggerStyle();

    const k = 1 / zoom;
    const size = triggerSize() * k;
    const gap = 6 * k;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const seg = found.anchor.rect;

    let x;
    let y;
    if (found.atMouse) {
      
      
      const off = MOUSE_GAP * k;
      x = seg.left + off;
      y = seg.bottom + off;
      if (x + size > vw - gap) x = seg.left - size - off;
      if (y + size > vh - gap) y = seg.bottom - size - off;
    } else {
      
      x = seg.right + gap;
      y = seg.bottom + gap;
      if (x + size > vw - gap) x = seg.left - size - gap;
      if (y + size > vh - gap) y = seg.top - size - gap;
    }
    x = Math.max(gap, Math.min(x, vw - size - gap));
    y = Math.max(gap, Math.min(y, vh - size - gap));

    trigger.style.left = x + 'px';
    trigger.style.top = y + 'px';
    trigger.classList.add('show');
    trigShownAt = Date.now();
    armTriggerIdle();
    trigger.dataset.pendingText = found.text;
    
    
    trigger.__anchor = found.panelRect || found.anchor.rect;
  }

  function onSelectionMaybeChanged() {
    window.setTimeout(updateTrigger, 10);
  }

  document.addEventListener('mouseup', (e) => {
    if (e.composedPath && e.composedPath().includes(host)) return;
    lastMouse = { x: e.clientX, y: e.clientY };
    onSelectionMaybeChanged();
  }, true);

  
  
  
  
  
  document.addEventListener('mousemove', (e) => {
    lastMouse = { x: e.clientX, y: e.clientY };
    if (!trigger.classList.contains('show')) return;

    if (e.composedPath && e.composedPath().includes(trigger)) {
      
      
      if (Date.now() - trigShownAt < 250) return;
      trigHovered = true;
      clearTriggerTimers();
      return;
    }
    
    if (trigHovered) { trigHovered = false; armTriggerLeave(); return; }
    
    
    
    if (trigLeaveTimer) return;
    armTriggerIdle();
  }, { capture: true, passive: true });

  document.addEventListener('keyup', (e) => {
    if (e.key === 'Shift' || e.key === 'Escape' || e.shiftKey) {
      
      if (e.key !== 'Escape') lastMouse = null;
      onSelectionMaybeChanged();
    }
  }, true);

  document.addEventListener('mousedown', (e) => {
    if (e.composedPath && e.composedPath().includes(host)) return;
    hideTrigger();
  }, true);

  
  document.addEventListener('contextmenu', (e) => {
    if (e.composedPath && e.composedPath().includes(host)) return;
    lastRightClick = { x: e.clientX, y: e.clientY };
  }, true);

  window.addEventListener('scroll', hideTrigger, { passive: true });

  




  window.addEventListener('message', (e) => {
    const m = e.data;
    if (!m || m.type !== 'rt-frame-sel' || e.source === window) return;
    if (!prefs.frameBridge) return;

    let base = null;
    for (const f of document.querySelectorAll('iframe, frame')) {
      if (f.contentWindow === e.source) {
        const r = f.getBoundingClientRect();
        base = { left: r.left, top: r.top, right: r.right, bottom: r.bottom };
        break;
      }
    }
    if (!base) return;

    if (!String(m.text || '').trim() || !m.rect) {
      
      if (lastFrameSel) {
        lastFrameSel = null;
        if (!readSelection()) hideTrigger();
      }
      return;
    }

    let left = base.left + m.rect.left;
    let top = base.top + m.rect.top;
    let right = base.left + m.rect.right;
    let bottom = base.top + m.rect.bottom;
    for (const t of m.trail || []) {
      left += t.left;
      top += t.top;
      right += t.right;
      bottom += t.bottom;
    }
    lastFrameSel = {
      text: String(m.text),
      anchor: { rect: { left, top, right, bottom } },
      atMouse: false
    };
    onSelectionMaybeChanged();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && panel.classList.contains('show')) {
      hidePanel();
    }
  }, true);

  trigger.addEventListener('mousedown', (e) => {
    
    e.preventDefault();
    e.stopPropagation();
  });

  trigger.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    const text = trigger.dataset.pendingText || (readSelection() || {}).text || '';
    if (text) openWith(text, trigger.__anchor);
  });

  

  panel.querySelector('[data-act="close"]').addEventListener('click', hidePanel);

  srcBtn.addEventListener('click', () => {
    prefs.showOriginal = !prefs.showOriginal;
    syncSrcBtn();
    saveSetting('showOriginal', prefs.showOriginal);
    keepPanelInView();   
  });

  moreBtn.addEventListener('click', () => {
    if (moreBtn.hidden) return;
    diagOpen = !diagOpen;
    diagBox.hidden = !diagOpen || diagBox.childElementCount === 0;
    keepPanelInView();   
  });

  
  async function copyText(text) {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setStatus('已复制');
    } catch {
      
      const ta = document.createElement('textarea');
      ta.value = text;
      ta.style.cssText = 'position:fixed;opacity:0;';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); setStatus('已复制'); } catch { setStatus('复制失败', 'err'); }
      ta.remove();
    }
  }

  

  async function onActClick(e) {
    

    const del = e.target.closest && e.target.closest('.rt-slot-x');
    if (del) {
      e.preventDefault();
      e.stopPropagation();
      const cidDel = del.getAttribute('data-del');
      if (!cidDel) return;
      
      const goneName = (slotBy(cidDel) || {}).name || '这条配置';
      removeSlot(cidDel);
      renderConfigOptions();
      


      if (slots.length > 1) {
        renderSlots();
      } else {
        

        const only = slots[0];
        const hit = resultCache.get(only.configId);
        if (hit) {
          renderResult(hit.r, hit.ocr, hit.action, hit.fatal);
        } else if (only && only.text) {
          renderResult({ text: only.text }, null, lastAction, false);
        } else {
          showNoCachedResult(only ? only.configId : '');
        }
      }
      setStatus('已收起「' + goneName + '」（本次显示，不改设置里的默认组合）');
      return;
    }

    const btn = e.target.closest && e.target.closest('.rt-act');
    if (!btn || btn.disabled) return;
    e.preventDefault();
    e.stopPropagation();
    const act = btn.dataset.act;
    const cid = btn.dataset.cid || '';
    
    const slot = cid ? slotBy(cid) : null;
    const text = slot ? slot.text : (outBox.textContent || '');

    if (act === 'copy') {
      await copyText(text);
      return;
    }
    if (act === 'speak') {
      toggleSpeak(cid, text);
      return;
    }
    if (act === 'retry-one') {
      retryOne(cid);
    }
  }
  outBox.addEventListener('click', onActClick);

  







  function retryOne(cid) {
    const id = cid || shownConfigId();
    
    if (!currentText && !(lastOcr && lastOcr.image)) {
      retryShot();
      return;
    }
    const sl = slotBy(id);
    
    if (sl && sl.state === 'busy') return;
    if (sl) {
      sl.state = 'busy';
      



      sl.error = '';
      sl.statusText = '';
      if (slots.length > 1) renderSlots();
    }
    
    if (!sl && busy) return;
    translate(currentText, id, lastOcr || undefined);
  }

  



  function toggleSpeak(cid, text) {
    const synth = window.speechSynthesis;
    if (!synth) {
      setStatus('这个浏览器不支持朗读', 'err');
      return;
    }
    
    if (speakingKey && speakingKey === cid) {
      synth.cancel();
      speakingKey = '';
      refreshActs();
      return;
    }
    const body = String(text || '').trim();
    if (!body) return;
    synth.cancel(); 
    ensureVoices(synth);
    const u = new SpeechSynthesisUtterance(body);
    const tags = speechTagsFor(prefs.targetLang);
    const voices = synth.getVoices() || [];
    const hit = pickVoice(voices, tags);
    if (hit) {
      u.voice = hit;
      u.lang = hit.lang;
    } else {
      


      u.lang = tags[0];
    }
    u.onend = () => {
      if (speakingKey === cid) {
        speakingKey = '';
        refreshActs();
      }
    };
    u.onerror = () => {
      if (speakingKey === cid) {
        speakingKey = '';
        refreshActs();
      }
    };
    speakingKey = cid;
    refreshActs();
    synth.speak(u);
  }

  














  function speechTagsFor(lang) {
    const s = String(lang || '').trim().toLowerCase();
    

    if (/繁体|繁體|hant|zh-tw|zh-hk|traditional/.test(s)) return ['zh-TW', 'zh-HK'];
    

    if (/简体|汉语|^中文$|^中文[^繁]|chs|hans|zh-cn|zh-hans/.test(s) ||
        s === 'zh' || s === 'chinese' || s === '') {
      return ['zh-CN', 'zh-Hans'];
    }
    

    if (s === '中文' || s === 'zh-hans' || s === 'zh_cn') return ['zh-CN', 'zh-Hans'];
    if (/^英|english|^en$/.test(s)) return ['en-US', 'en-GB'];
    if (/^日|japanese|^ja$/.test(s)) return ['ja-JP'];
    if (/^韩|^朝鲜|korean|^ko$/.test(s)) return ['ko-KR'];
    if (/^法|french|^fr$/.test(s)) return ['fr-FR'];
    if (/^德|german|^de$/.test(s)) return ['de-DE'];
    if (/^西班牙|spanish|^es$/.test(s)) return ['es-ES'];
    if (/^俄|russian|^ru$/.test(s)) return ['ru-RU'];
    if (/^葡萄牙|portuguese|^pt$/.test(s)) return ['pt-BR', 'pt-PT'];
    if (/^意大利|italian|^it$/.test(s)) return ['it-IT'];
    if (/^阿拉伯|arabic|^ar$/.test(s)) return ['ar-SA'];
    if (/^泰|thai|^th$/.test(s)) return ['th-TH'];
    if (/^越南|vietnamese|^vi$/.test(s)) return ['vi-VN'];
    if (/^印尼|indonesian|^id$/.test(s)) return ['id-ID'];
    if (/^土耳其|turkish|^tr$/.test(s)) return ['tr-TR'];
    if (/^荷兰|dutch|^nl$/.test(s)) return ['nl-NL'];
    if (/^波兰|polish|^pl$/.test(s)) return ['pl-PL'];
    if (/^乌克兰|ukrainian|^uk$/.test(s)) return ['uk-UA'];
    if (/^捷克|czech|^cs$/.test(s)) return ['cs-CZ'];
    if (/^瑞典|swedish|^sv$/.test(s)) return ['sv-SE'];
    if (/^挪威|norwegian|^nb$|^no$/.test(s)) return ['nb-NO', 'no-NO'];
    if (/^丹麦|danish|^da$/.test(s)) return ['da-DK'];
    if (/^芬兰|finnish|^fi$/.test(s)) return ['fi-FI'];
    if (/^希腊|greek|^el$/.test(s)) return ['el-GR'];
    if (/^匈牙利|hungarian|^hu$/.test(s)) return ['hu-HU'];
    if (/^罗马尼亚|romanian|^ro$/.test(s)) return ['ro-RO'];
    
    return [String(lang || '').trim() || 'zh-CN'];
  }

  
  const SPEECH_DIALECT_TAGS = ['zh-hk', 'zh-tw', 'zh-hant', 'yue', 'hk', 'tw'];

  



  function pickVoice(voices, tags) {
    if (!voices || !voices.length) return null;
    const norm = (v) => String(v.lang || '').toLowerCase().replace(/_/g, '-');
    for (const tag of tags) {
      const t = tag.toLowerCase();
      const exact = voices.filter((v) => norm(v) === t);
      if (exact.length) return exact.find((v) => v.localService) || exact[0];
    }
    
    for (const tag of tags) {
      const t = tag.toLowerCase();
      const prefix = voices.filter((v) => {
        const L = norm(v);
        if (!L.startsWith(t.split('-')[0])) return false;
        
        if (SPEECH_DIALECT_TAGS.some((d) => L.includes(d))) return false;
        return true;
      });
      if (prefix.length) return prefix.find((v) => v.localService) || prefix[0];
    }
    return null;
  }

  




  let voicesPrimed = false;
  function ensureVoices(synth) {
    if (voicesPrimed) return;
    voicesPrimed = true;
    if (synth.getVoices().length) return;
    
    try {
      synth.addEventListener?.('voiceschanged', () => {}, { once: true });
    } catch {
      
    }
  }

  
  function refreshActs() {
    
    renderSlots();
  }


  



  cfgSelect.addEventListener('change', async () => {
    const v = cfgSelect.value;
    if (!v) return;
    


    


    const already = slots.some((sl) => sl.configId === v);
    const primary = cfgMode === 'image' ? imageConfigId : currentConfigId;
    if (already && v === primary) return;
    if (cfgMode === 'image') imageConfigId = v;
    else currentConfigId = v;
    







    const max = Math.max(1, slotLimit());
    const head = prefs.slotInsert === 'head';
    if (already) {
      
      const rest = slots.filter((sl) => sl.configId !== v);
      slots = head ? [slotBy(v), ...rest] : [...rest, slotBy(v)];
    } else if (head) {
      slots = [makeSlot(v), ...slots].slice(0, max);
    } else {
      slots = [...slots, makeSlot(v)].slice(-max);
    }
    



    if (cfgMode === 'image') await saveImageConfigId(v);
    renderConfigOptions();
    
    const hit = resultCache.get(v);
    if (hit) {
      
      renderSlotResult(v, hit.r, hit.ocr, hit.action, hit.fatal);
      leaveBusy();
      return;
    }
    if (currentText || (lastOcr && lastOcr.image)) {
      translate(currentText, v, lastOcr || undefined);
      return;
    }
    showNoCachedResult(v);
  });

  


  langSelect.addEventListener('change', async () => {
    const v = langSelect.value;
    if (v === prefs.targetLang) return;
    prefs.targetLang = v;
    langSelect.title = '目标语言：' + v;
    
    resultCache.clear();
    
    
    
    await saveSetting('targetLang', v);
    if (currentText || (lastOcr && lastOcr.image)) {
      translate(currentText, shownConfigId(), lastOcr || undefined);
      return;
    }
    setStatus('目标语言：' + v);
  });

  
  (() => {
    let dragging = false;
    let sx = 0;
    let sy = 0;
    let px = 0;
    let py = 0;

    const head = panel.querySelector('[data-drag]');
    head.addEventListener('mousedown', (e) => {
      if (e.target.closest('.rt-btn') || e.target.closest('.rt-cfg') ||
          e.target.closest('.rt-lang')) return;
      dragging = true;
      sx = e.clientX;
      sy = e.clientY;
      px = parseFloat(panel.style.left) || 0;
      py = parseFloat(panel.style.top) || 0;
      e.preventDefault();
    });

    window.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      
      
      const p = clampPanel(px + e.clientX - sx, py + e.clientY - sy);
      panel.style.left = p.x + 'px';
      panel.style.top = p.y + 'px';
    }, true);

    window.addEventListener('mouseup', () => {
      dragging = false;
    }, true);
  })();

  

  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg) return;

    
    if (msg.type === 'rt-zoom' && typeof msg.zoom === 'number') {
      setZoom(msg.zoom);
      return;
    }

    
    if (msg.type === 'hotkey-translate') {
      const r = readSelection();
      if (!r) return;
      openWith(r.text, (r.panelRect || (r.anchor && r.anchor.rect)) || null);
      return;
    }

    if (msg.type !== 'rt-translate-selection') {
      
      if (msg.type === 'rt-ocr-clipboard') {
        
        
        const pt = msg.via === 'hotkey' ? lastMouse : lastRightClick;
        startOcr(pt ? pointRect(pt.x, pt.y) : null);
      }
      
      if (msg.type === 'rt-shot-translate') {
        startShot(msg.dataUrl, msg.error);
      }
      return;
    }
    const text = String(msg.text || '').trim();
    if (!text) return;
    const sel = window.getSelection();
    let rect = null;
    try {
      if (sel && sel.rangeCount) rect = sel.getRangeAt(0).getBoundingClientRect();
    } catch {  }
    openWith(text, rect);
  });

  

  function applyState(state) {
    if (!state) return;
    if (Array.isArray(state.configs)) {
      
      
      applyConfigList(state.configs.map((c) => ({ ...c, img: imageCapable(c) })));
    }
    if (state.ocr) imageConfigId = String(state.ocr.imageConfigId || '');
    if (state.activeConfigId) activeConfigId = state.activeConfigId;
    const prevLang = prefs.targetLang;
    if (state.settings) prefs = { ...prefs, ...state.settings };
    
    
    if (prevLang !== prefs.targetLang) resultCache.clear();
    if (!currentConfigId) currentConfigId = activeConfigId;
    renderConfigOptions();
    renderLangOptions();
    syncSrcBtn();
    applyAppearance();
    
    refreshShellText();
    
    keepPanelInView();
    if (prefs.trigger === 'off') hideTrigger();
  }

  

  try {
    const i18nApi = window.RTI18n;
    const loadPack = i18nApi && i18nApi.loadPack ? i18nApi.loadPack() : Promise.resolve(null);
    Promise.all([loadPack, chrome.storage.local.get('state')])
      .then(([, raw]) => applyState(raw && raw.state))
      .catch(() => {});
  } catch {  }

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.state) return;
      applyState(changes.state.newValue);
    });
  } catch {  }

  mount();
  syncSrcBtn();
  applyAppearance();
  syncZoom();
})();
