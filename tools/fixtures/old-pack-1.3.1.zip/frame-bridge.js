





















(() => {
  if (window.top === window) return; 

  let lastText = '';
  let debounce = 0;

  const send = (msg) => {
    try {
      window.parent.postMessage(msg, '*');
    } catch {
      
    }
  };

  const rectOf = (sel) => {
    try {
      const r = sel.getRangeAt(0).getBoundingClientRect();
      if (r && (r.width || r.height)) {
        return { left: r.left, top: r.top, right: r.right, bottom: r.bottom };
      }
    } catch {
      
    }
    return null;
  };

  document.addEventListener('selectionchange', () => {
    clearTimeout(debounce);
    debounce = setTimeout(() => {
      const sel = window.getSelection();
      const text = (sel && sel.toString()) || '';
      if (text.trim() && text !== lastText) {
        lastText = text;
        





        send({ type: 'rt-frame-sel', text, rect: rectOf(sel), trail: [] });
      } else if (!text.trim() && lastText) {
        
        lastText = '';
        send({ type: 'rt-frame-sel', text: '', rect: null, trail: [] });
      }
    }, 120);
  });

  
  window.addEventListener('message', (e) => {
    const m = e.data;
    if (!m || m.type !== 'rt-frame-sel') return;
    let fr = null;
    for (const f of document.querySelectorAll('iframe, frame')) {
      if (f.contentWindow === e.source) {
        fr = f.getBoundingClientRect();
        break;
      }
    }
    if (!fr) return; 
    const trail = [...(m.trail || []), { left: fr.left, top: fr.top, right: fr.right, bottom: fr.bottom }];
    send({ ...m, trail });
  });
})();
