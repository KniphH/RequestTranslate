















import { loadState, pickRequestConfig, canTranslateImage, buildVars } from './lib/store.js';
import { requestTemplateFor, requestChain } from './lib/requests.js';
import { modelCandidates, modelVarFor } from './lib/template.js';
import { runRequest } from './lib/engine.js';
import {
  OCR_MENU_ID,
  ocrMenuItem,
  SHOT_MENU_ID,
  shotMenuItem,
  activeOcrProvider,
  runOcr
} from './lib/ocr.js';
import { NO_IMAGE_MESSAGE, CLIPBOARD_UNAVAILABLE_MESSAGE } from './lib/clipboard.js';
import { readClipboardImage as readClipboardInPage, errText as clipErrText } from './lib/clipboard-read.js';


import { TARGET_PRESETS } from './lib/template.js';

const PORT_NAME = 'rt-translate';
const MENU_ID = 'rt-translate-selection';






let menuPending = null;
function ensureMenu() {
  if (menuPending) return menuPending;
  menuPending = (async () => {
    try {
      await chrome.contextMenus.removeAll();
      const state = await loadState();

      if (state.settings.contextMenu) {
        chrome.contextMenus.create({
          id: MENU_ID,
          title: '用 RequestTranslate 翻译选中内容',
          contexts: ['selection']
        });
      }

      
      
      const ocrItem = ocrMenuItem(state.settings);
      if (ocrItem) chrome.contextMenus.create(ocrItem);

      
      const shotItem = shotMenuItem(state.settings);
      if (shotItem) chrome.contextMenus.create(shotItem);
    } catch {
      
    } finally {
      menuPending = null;
    }
  })();
  return menuPending;
}





chrome.commands.onCommand.addListener(async (command) => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || typeof tab.id !== 'number') return;

    if (command === 'translate-selection') {
      await chrome.tabs.sendMessage(tab.id, { type: 'hotkey-translate' });
      return;
    }
    if (command === 'ocr-clipboard') {
      
      await chrome.tabs.sendMessage(tab.id, { type: 'rt-ocr-clipboard', via: 'hotkey' });
      return;
    }
    if (command === 'shot-translate') {
      try {
        const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
        await chrome.tabs.sendMessage(tab.id, { type: 'rt-shot-translate', dataUrl });
      } catch (err) {
        await chrome.tabs
          .sendMessage(tab.id, { type: 'rt-shot-translate', error: String((err && err.message) || err) })
          .catch(() => {});
      }
    }
  } catch {
    
  }
});

chrome.runtime.onInstalled.addListener(() => {
  ensureMenu();
});
chrome.runtime.onStartup.addListener(() => {
  ensureMenu();
});
ensureMenu();

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || tab.id == null) return;

  if (info.menuItemId === MENU_ID) {
    const text = (info.selectionText || '').trim();
    if (!text) return;
    chrome.tabs.sendMessage(tab.id, { type: 'rt-translate-selection', text }).catch(() => {
      
    });
    return;
  }

  
  
  if (info.menuItemId === OCR_MENU_ID) {
    chrome.tabs.sendMessage(tab.id, { type: 'rt-ocr-clipboard' }).catch(() => {
      
    });
    return;
  }

  
  
  
  if (info.menuItemId === SHOT_MENU_ID) {
    chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' })
      .then((dataUrl) => chrome.tabs.sendMessage(tab.id, { type: 'rt-shot-translate', dataUrl }))
      .catch((err) => {
        
        chrome.tabs
          .sendMessage(tab.id, { type: 'rt-shot-translate', error: String((err && err.message) || err) })
          .catch(() => {});
      });
  }
});






chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'rt-get-zoom') return false;

  const tabId = sender && sender.tab ? sender.tab.id : null;
  if (typeof tabId !== 'number') {
    sendResponse(1);
    return false;
  }

  chrome.tabs
    .getZoom(tabId)
    .then((z) => sendResponse(typeof z === 'number' && z > 0 ? z : 1))
    .catch(() => sendResponse(1));
  return true; 
});

chrome.tabs.onZoomChange.addListener((info) => {
  if (!info || typeof info.tabId !== 'number') return;
  chrome.tabs.sendMessage(info.tabId, { type: 'rt-zoom', zoom: info.newZoomFactor }).catch(() => {
    
  });
});






const OFFSCREEN_PATH = 'offscreen.html';





function hasOffscreen() {
  return !!(chrome.offscreen && chrome.offscreen.createDocument);
}


let offscreenPending = null;

async function ensureOffscreen() {
  if (offscreenPending) {
    await offscreenPending;
    return;
  }
  offscreenPending = (async () => {
    try {
      await chrome.offscreen.createDocument({
        url: OFFSCREEN_PATH,
        reasons: ['CLIPBOARD'],
        justification: '读取剪切板里的截图，交给 OCR 模型识别成文字'
      });
    } catch (err) {
      
      if (!/single offscreen/i.test(String((err && err.message) || err))) throw err;
    }
  })();
  try {
    await offscreenPending;
  } finally {
    offscreenPending = null;
  }
}





async function askOffscreen(msg) {
  const payload = { ...msg, target: 'rt-offscreen' };
  try {
    return await chrome.runtime.sendMessage(payload);
  } catch {
    await new Promise((r) => setTimeout(r, 200));
    return await chrome.runtime.sendMessage(payload);
  }
}









let clipboardRead = Promise.resolve();
function readClipboardImage() {
  const run = async () => {
    



    if (!hasOffscreen()) {
      try {
        return await readClipboardInPage(document);
      } catch (err) {
        return { ok: false, reason: 'unavailable', error: clipErrText(err) };
      }
    }
    await ensureOffscreen();
    try {
      const r = await askOffscreen({ type: 'read-image' });
      if (!r) return { ok: false, reason: 'unavailable' };
      return r;
    } catch (err) {
      return { ok: false, reason: 'unavailable', error: String((err && err.message) || err) };
    } finally {
      try {
        await chrome.offscreen.closeDocument();
      } catch {
        
      }
    }
  };
  clipboardRead = clipboardRead.then(run, run);
  return clipboardRead;
}




let historyQueue = Promise.resolve();














function appendHistory(entry, max) {
  const run = async () => {
    try {
      const { state: fresh } = await chrome.storage.local.get('state');
      if (!fresh) return;
      fresh.history = [entry, ...(Array.isArray(fresh.history) ? fresh.history : [])].slice(0, max);
      await chrome.storage.local.set({ state: fresh });
    } catch {
      
    }
  };
  historyQueue = historyQueue.then(run, run);
  return historyQueue;
}



chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== PORT_NAME) return;

  



  let runBatch = 0;
  
  const runCtrls = new Map();
  
  
  let ocrController = null;
  
  let ocrSeq = 0;
  


  let lastShot = null;

  
  const hasImageInContext = (m) => !!(m.context && m.context.image);

  const safePost = (msg) => {
    try {
      port.postMessage(msg);
    } catch {
      
    }
  };

  port.onMessage.addListener(async (msg) => {
    if (!msg || typeof msg !== 'object') return;

    if (msg.type === 'abort') {
      



      runBatch += 1;
      for (const c of runCtrls.values()) c.abort();
      runCtrls.clear();
      ocrSeq += 1;
      if (ocrController) ocrController.abort();
      ocrController = null;
      return;
    }

    if (msg.type === 'hello') {
      const state = await loadState();
      safePost({
        type: 'ready',
        

        configs: state.configs.map((c) => ({ id: c.id, name: c.name, img: canTranslateImage(c) })),
        activeConfigId: state.activeConfigId,
        
        imageConfigId: state.ocr.imageConfigId,
        settings: state.settings,
        targetLangs: TARGET_PRESETS
      });
      return;
    }

    



    if (msg.type === 'ocr') {
      const mySeq = ++ocrSeq;

      const state = await loadState();
      

      if (mySeq !== ocrSeq) return;
      const toModel = state.ocr.disabled === true;
      const provider = toModel ? null : activeOcrProvider(state.ocr);
      if (!toModel && !provider) {
        safePost({ type: 'ocr-error', message: '还没有配置 OCR 供应商，去设置页的「OCR」里加一条' });
        return;
      }

      
      const passed = typeof msg.dataUrl === 'string' && msg.dataUrl.startsWith('data:image/');
      let shot;
      if (passed) {
        shot = { ok: true, dataUrl: msg.dataUrl, bytes: Math.round(msg.dataUrl.length * 3 / 4) };
      } else if (msg.reuse && lastShot) {
        shot = lastShot;
      } else {
        safePost({ type: 'ocr-status', message: '正在读取剪切板…' });
        try {
          shot = await readClipboardImage();
        } catch (err) {
          shot = { ok: false, reason: 'unavailable', error: String((err && err.message) || err) };
        }
      }
      if (mySeq !== ocrSeq) return;

      if (!shot || !shot.ok) {
        const reason = (shot && shot.reason) || 'unavailable';
        safePost({
          type: 'ocr-error',
          message: reason === 'no-image'
            ? NO_IMAGE_MESSAGE
            : CLIPBOARD_UNAVAILABLE_MESSAGE + ((shot && shot.error) ? '（' + shot.error + '）' : '')
        });
        return;
      }
      lastShot = shot;

      if (toModel) {
        safePost({ type: 'ocr-image', dataUrl: shot.dataUrl, bytes: shot.bytes });
        return;
      }

      safePost({ type: 'ocr-status', message: `正在识别截图（${provider.name}）…` });

      let out;
      try {
        if (ocrController) ocrController.abort();
        ocrController = new AbortController();
        
        
        out = await runOcr({
          provider,
          dataUrl: shot.dataUrl,
          vars: buildVars(state, '', {}),
          signal: ocrController.signal
        });
      } catch (err) {
        if (mySeq === ocrSeq) {
          safePost({ type: 'ocr-error', message: (err && err.message) || String(err) });
        }
        return;
      }

      if (mySeq !== ocrSeq) return;
      safePost({
        type: 'ocr-text',
        text: out.text,
        provider: provider.name,
        ms: out.ms,
        bytes: shot.bytes
      });
      return;
    }

    if (msg.type === 'translate') {
      

      const ids = Array.isArray(msg.configIds) && msg.configIds.length
        ? msg.configIds.map((x) => String(x || ''))
        : [String(msg.configId || '')];

      
      
      const myBatch = ++runBatch;
      for (const c of runCtrls.values()) c.abort();
      runCtrls.clear();

      const state = await loadState();
      
      const text = String(msg.text || '').slice(0, Math.max(1, Number(state.settings.maxChars) || 8000));
      const vars = buildVars(state, text, msg.context || {});

      


      const runOne = async (wantId) => {
        
        
        const config = pickRequestConfig(state, wantId, !!(msg.context && msg.context.image));
        if (!config) {
          safePost({ type: 'fatal', configId: wantId, message: '没有任何可用配置，请先到设置页新建一条' });
          return;
        }
        
        const cid = config.id;
        const ctrl = new AbortController();
        runCtrls.set(cid, ctrl);
        
        const alive = () => myBatch === runBatch && !ctrl.signal.aborted;

        










        const hasImage = hasImageInContext(msg);
        const runnable = hasImage
          ? requestChain(config).filter((it) => String(it.imageRequest || '').trim())
          : requestChain(config);
        if (hasImage && !runnable.length) {
          safePost({ type: 'fatal', configId: cid, message: '这条配置没填「图片请求模板」，没法带图翻译' });
          runCtrls.delete(cid);
          return;
        }

        let result = null;
        for (let r = 0; r < runnable.length; r += 1) {
          const item = runnable[r];
          
          const requestText = requestTemplateFor(item, msg.context || {});
          
          
          const label = item.main ? '' : (item.name || '');

          


          const mkey = modelVarFor(requestText, vars);
          const models = modelCandidates(requestText, vars);
          const attempts = models.length ? models : [null];

          for (let i = 0; i < attempts.length; i += 1) {
            const model = attempts[i];
            
            const runVars = model == null ? vars : { ...vars, [mkey]: model };
            const bits = [label, model].filter(Boolean).join(' · ');
            const statusText = bits ? `（${bits}）` : '';

            safePost({
              type: 'start',
              configId: cid,
              configName: config.name,
              text,
              statusText
            });

            try {
              result = await runRequest({
                requestText,
                adapter: item.adapter,
                vars: runVars,
                path: item.path,
                responseMode: item.responseMode,
                signal: ctrl.signal,
                onDelta: (current) => {
                  if (!alive()) return;
                  safePost({ type: 'delta', configId: cid, text: current });
                }
              });
            } catch (err) {
              if (!alive()) return;
              safePost({ type: 'fatal', configId: cid, message: err && err.message ? err.message : String(err) });
              runCtrls.delete(cid);
              return;
            }

            
            if (!alive()) return;
            
            
            if (result && result.error === '已取消') return;

            
            
            if (result && result.text) break;
          }

          
          if (result && result.text) break;
        }

        if (!alive()) return;

        


        if (result && result.text) {
          const max = Math.max(0, Number(state.settings.historyMax) || 0);
          if (max > 0) {
            await appendHistory({
              src: text.slice(0, 2000),
              dst: String(result.text).slice(0, 5000),
              configName: config.name,
              lang: state.settings.targetLang || '',
              ts: Date.now()
            }, max);
          }
        }

        runCtrls.delete(cid);
        safePost({ type: 'done', configId: cid, result: { ...result, raw: undefined } });
      };

      
      await Promise.all(ids.map((id) => runOne(id)));
    }
  });

  port.onDisconnect.addListener(() => {
    for (const c of runCtrls.values()) c.abort();
    runCtrls.clear();
    


    if (ocrController) ocrController.abort();
    ocrController = null;
  });
});



let menuTimer = null;

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local' || !changes.state) return;
  
  clearTimeout(menuTimer);
  menuTimer = setTimeout(ensureMenu, 1500);
});
