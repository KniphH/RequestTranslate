





import {
  loadState,
  saveState,
  buildVars,
  exportState,
  importState,
  moveItem,
  moveVisibleItem,
  dropIndex,
  canTranslateImage,
  PANEL_OWNED_SETTING_KEYS,
  adoptPanelOwned,
  getConfig
} from './lib/store.js';




const { TRIGGER_CSS, PANEL_CSS } = window.RTPanelCore;



function T(key, fallback) {
  const api = window.RTI18n;
  if (api && typeof api.t === "function") {
    const got = api.t(key);
    if (got && got !== key) return got;
  }
  return fallback;
}


import { uid, allRequests, requestChain, requestTemplateFor } from './lib/requests.js';
import { runRequest, previewRequest } from './lib/engine.js';
import { encryptExport, decryptExport, isEncryptedExport } from './lib/crypto.js';
import { ADAPTERS } from './lib/adapters.js';
import { BUILTIN_VAR_HINTS, TARGET_PRESETS, isSecretVar, modelCandidates, modelVarFor } from './lib/template.js';
import {
  toDataUrl,
  pickImageMime,
  NO_IMAGE_MESSAGE,
  CLIPBOARD_UNAVAILABLE_MESSAGE
} from './lib/clipboard.js';
import { TRIGGER_STYLES, TRIGGER_SVG_SAMPLE, getTriggerStyle, clampTriggerSize, parseTriggerSvg } from './lib/trigger-styles.js';
import {
  OCR_PROVIDERS,
  BUILTIN_OCR_IDS,
  normalizeOcrProvider,
  normalizeOcrItem,
  previewOcrRequest,
  runOcr,
  runImageTranslate
} from './lib/ocr.js';



let state = null;
let editingId = '';
let editingOcrId = '';
let saveTimer = null;

const panelTouched = new Set();

let ocrTestFile = null;

let focusedTemplate = null;


let blockFold = new Map();

const $ = (sel) => document.querySelector(sel);

const els = {
  cfgList: $('#cfg-list'),
  editor: $('#editor'),
  emptyHint: $('#empty-hint'),
  

  cfgHead: $('#cfg-head'),
  name: null,
  
  blocks: $('#req-blocks'),
  btnAddFallback: $('#btn-add-fallback'),
  trigStyles: $('#trig-styles'),
  trigSvg: $('#s-trigsvg'),
  trigSvgMsg: $('#s-trigsvg-msg'),
  btnTrigSvgDemo: $('#btn-trigsvg-demo'),
  btnTrigSvgClear: $('#btn-trigsvg-clear'),
  trigPreview: $('#trig-preview'),
  preview: $('#f-preview'),
  testText: $('#test-text'),
  testResult: $('#test-result'),
  varsBody: $('#vars-body'),
  builtinBody: $('#builtin-body'),
  fileImport: $('#file-import'),
  chkEncrypt: $('#chk-encrypt'),
  panelCss: $('#s-panelcss'),
  btnPanelCssWarm: $('#btn-panelcss-warm'),
  btnPvOpen: $('#btn-pv-open'),
  btnPanelCssClear: $('#btn-panelcss-clear'),
  passDialog: $('#pass-dialog'),
  langSelect: $('#s-lang'),
  langOther: $('#s-lang-other'),

  
  ocrList: $('#ocr-list'),
  
  imgcfgList: $('#imgcfg-list'),
  imgcfgFoot: $('#imgcfg-foot'),
  ocrHead: $('#ocr-head'),
  imgcfgHint: null,
  oName: null,
  oNote: null,
  ocrListTitle: $('#ocr-list-title'),
  ocrEditor: $('#ocr-editor'),
  ocrEmpty: $('#ocr-empty'),
  
  ocrBlocks: $('#ocr-blocks'),
  btnOcrAddFallback: $('#btn-ocr-add-fallback'),
  oPreview: $('#o-preview'),
  oDisabled: $('#o-disabled'),
  btnOcrNew: $('#btn-ocr-new'),
  btnOcrDuplicate: $('#btn-ocr-duplicate'),
  btnOcrDelete: $('#btn-ocr-delete'),
  ocrTestImg: $('#ocr-test-img'),
  ocrTestBtn: $('#btn-ocr-test'),
  ocrTestResult: $('#ocr-test-result'),
  oPreviewSummary: $('#o-preview-summary'),
  oTestLabel: $('#o-test-label'),
  ocrTestHint: $('#ocr-test-hint'),
  imgcfgTestHint: $('#imgcfg-test-hint')
};

function escapeHtml(s) {
  return String(s ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}



init().catch((err) => {
  document.body.innerHTML =
    '<pre style="padding:24px;color:#f87171">' + T('opt_err_boot', '设置页初始化失败：') + escapeHtml(err && err.message) + '</pre>';
});

async function init() {
  

  const i18nApi = window.RTI18n;
  const loadPack = i18nApi && i18nApi.loadPack ? i18nApi.loadPack() : Promise.resolve(null);
  const [state0] = await Promise.all([loadState(), loadPack]);
  state = state0;

  

  if (i18nApi && i18nApi.applyI18n) i18nApi.applyI18n(document);

  editingId = state.activeConfigId;
  editingOcrId = state.ocr.activeId;

  

  renderEditorHeads();

  bindTabs();
  bindConfigList();
  bindEditor();
  bindOcr();
  bindVars();
  bindSettings();
  bindImportExport();
  bindUiLang();

  renderConfigList();
  renderEditor();
  renderOcrList();
  renderOcrEditor();
  renderVars();
  renderSettings();
  syncGroupCounts();
  renderPanelPreview();
  applyHintHides();
}













function editorHeadHtml({ nameId, placeholder, top, bottom }) {
  const hint = (h) =>
    `<p class="hint wide"${h.id ? ` id="${h.id}"` : ''}` +
    `${h.hint ? ` data-hint="${h.hint}"` : ''}${h.hidden ? ' hidden' : ''}>${h.html || ''}</p>`;
  return `
    <div class="hint-slot">${top.map(hint).join('')}</div>
    <div class="editor-head">
      <div class="field grow">
        <label for="${nameId}">${T('opt_label_name', '名称')}</label>
        <input id="${nameId}" type="text" placeholder="${escapeHtml(placeholder)}" autocomplete="off">
      </div>
    </div>
    <div class="hint-slot">${hint(bottom)}</div>`;
}


function renderEditorHeads() {
  els.cfgHead.innerHTML = editorHeadHtml({
    nameId: 'f-name',
    placeholder: T('opt_ph_cfgname', '例如：DeepSeek 翻译 / 本地 Ollama'),
    top: [
      {
        hint: 'cfg-intro',
        html: T('opt_cfg_intro', '照着内置那条改：换地址、模型名、提示词，<b>占位符别动</b>。')
      }
    ],
    bottom: {
      hint: 'cfg-requests',
      html: T('opt_cfg_requests', '一条配置能挂好几条请求：<b>主请求</b>先发，它挂了就按顺序试勾上的<b>后备请求</b>。')
    }
  });

  els.ocrHead.innerHTML = editorHeadHtml({
    nameId: 'o-name',
    placeholder: T('opt_ph_ocrname', '例如：硅基流动'),
    top: [
      {
        id: 'o-hint',
        hint: 'ocr',
        html:
          '<b>「翻译剪切板中的截图」</b>和<b>「框选截图翻译」</b>都先用这里<b>选中</b>的配置把图转成文字，' +
          '再交给「配置」翻译。'
      },
      {
        id: 'imgcfg-hint',
        hint: 'imgcfg',
        hidden: true,
        html: '现在是<b>图片直传</b>：截图不过 OCR，直接交给左边选中那条的<b>「图片请求模板」</b>去翻。'
      }
    ],
    

    bottom: { id: 'o-note' }
  });

  


  els.name = els.cfgHead.querySelector('#f-name');
  els.oName = els.ocrHead.querySelector('#o-name');
  els.oNote = els.ocrHead.querySelector('#o-note');
  els.imgcfgHint = els.ocrHead.querySelector('#imgcfg-hint');
}



function bindTabs() {
  document.querySelectorAll('.tab').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach((b) => b.classList.toggle('is-active', b === btn));
      document.querySelectorAll('.tabpanel').forEach((p) => {
        p.classList.toggle('is-active', p.dataset.panel === btn.dataset.tab);
      });
      
      
      if (btn.dataset.tab === 'ocr' && state.ocr && state.ocr.disabled) {
        renderImageConfigList();
        renderOcrPreview();
      }
      
      
      if (btn.dataset.tab === 'vars') growVarValues();
      
      if (btn.dataset.tab === 'settings' && pvNeedsRender) renderPanelPreview();
    });
  });
}





const GRIP_SVG =
  '<svg width="10" height="14" viewBox="0 0 10 14" fill="currentColor" aria-hidden="true">' +
  '<circle cx="3" cy="2" r="1.15"/><circle cx="7" cy="2" r="1.15"/>' +
  '<circle cx="3" cy="7" r="1.15"/><circle cx="7" cy="7" r="1.15"/>' +
  '<circle cx="3" cy="12" r="1.15"/><circle cx="7" cy="12" r="1.15"/>' +
  '</svg>';



const EYE_SVG =
  '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
  'stroke-width="1.3" stroke-linecap="round" aria-hidden="true">' +
  '<path d="M1.6 8s2.5-4.3 6.4-4.3S14.4 8 14.4 8s-2.5 4.3-6.4 4.3S1.6 8 1.6 8Z"/>' +
  '<circle cx="8" cy="8" r="1.8"/></svg>';







const PV_SCALE = 0.42;

const PV_VIEWPORT_H = 800;




const SLOT_MIN = 1;
const SLOT_MAX = 4;
const clampSlots = (v) => Math.min(SLOT_MAX, Math.max(SLOT_MIN, Math.round(Number(v)) || SLOT_MIN));


const PREVIEW_KEYS = new Set(['fontSize', 'panelWidth', 'panelHeight', 'panelMaxHeight', 'panelCss']);

const EYE_OFF_SVG =
  '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" ' +
  'stroke-width="1.3" stroke-linecap="round" aria-hidden="true">' +
  '<path d="M1.6 8s2.5-4.3 6.4-4.3S14.4 8 14.4 8s-2.5 4.3-6.4 4.3S1.6 8 1.6 8Z"/>' +
  '<circle cx="8" cy="8" r="1.8"/><path d="M3.2 12.8 12.8 3.2"/></svg>';









function refreshConfigViews(save = true) {
  renderConfigList();
  renderEditor();
  if (save) persist(false);
}

function renderConfigList() {
  const total = state.configs.length;
  els.cfgList.innerHTML = '';

  state.configs.forEach((cfg, idx) => {
    els.cfgList.appendChild(sortableRow({
      id: cfg.id,
      name: cfg.name,
      sub: summarizeUrl(cfg.request, '(空)'),
      active: cfg.id === editingId,
      inCompare: slotConfigIds().includes(cfg.id),
      index: idx,
      total,
      listEl: els.cfgList,
      onSelect: () => selectConfig(cfg.id),
      onMove: moveConfig,
      onAddToCompare: toggleSlotConfig,
      onRemoveFromCompare: (cid) => toggleSlotConfig(cid, { force: false })
    }));
  });
  syncSlotsHint();
}


function slotConfigIds() {
  return Array.isArray(state.settings.slotConfigs) ? state.settings.slotConfigs : [];
}




function imgSlotConfigIds() {
  return Array.isArray(state.settings.imageSlotConfigs) ? state.settings.imageSlotConfigs : [];
}


















function toggleImgSlotConfig(id, opts) {
  const redraw = !(opts && opts.redraw === false);
  const cur = imgSlotConfigIds();
  const max = clampSlots(state.settings.panelSlots);
  const has = cur.includes(id);
  const force = opts && typeof opts.force === 'boolean' ? opts.force : !has;
  let next;
  if (force) {
    if (has) return;
    next = [...cur, id];
    if (next.length > max) next = next.slice(next.length - max);
  } else {
    if (!has) return;
    next = cur.filter((x) => x !== id);
  }
  
  const order = state.configs.map((c) => c.id);
  next.sort((a, b) => order.indexOf(a) - order.indexOf(b));
  state.settings.imageSlotConfigs = next;
  scheduleSave();
  if (redraw) renderImageConfigList();
}

function toggleSlotConfig(id, opts) {
  const redraw = !(opts && opts.redraw === false);
  const cur = slotConfigIds();
  const max = clampSlots(state.settings.panelSlots);
  const has = cur.includes(id);
  
  const force = opts && typeof opts.force === 'boolean' ? opts.force : !has;
  let next;
  if (force) {
    if (has) return;
    next = [...cur, id];
    if (next.length > max) next = next.slice(next.length - max); 
  } else {
    if (!has) return;
    next = cur.filter((x) => x !== id);
  }
  state.settings.slotConfigs = sortByConfigOrder(next);
  
  if (redraw) renderConfigList();
  persist(false);
  setSaveStatus(next.length ? `对比 ${next.length} 条` : '对比已清空');
}


function sortByConfigOrder(ids) {
  const order = new Map(state.configs.map((c, i) => [c.id, i]));
  return ids.slice().sort((a, b) => (order.get(a) ?? 1e9) - (order.get(b) ?? 1e9));
}


function syncSlotsHint() {
  const max = clampSlots(state.settings.panelSlots);
  const cur = slotConfigIds();
  if (cur.length > max) {
    state.settings.slotConfigs = cur.slice(cur.length - max);
  }
}











function sortableRow({ id, name, sub, active, inCompare, index, total, listEl, onSelect, onMove, onAddToCompare, onRemoveFromCompare }) {
  const row = document.createElement('div');
  row.className = 'cfg-row';
  row.dataset.id = id;

  const grip = document.createElement('span');
  grip.className = 'cfg-grip';
  grip.innerHTML = GRIP_SVG;
  grip.title = '按住拖动，调整顺序';
  grip.setAttribute('aria-hidden', 'true'); 

  const btn = document.createElement('button');
  btn.type = 'button';
  
  btn.className = 'cfg-item' + (active ? ' is-active' : '') + (inCompare ? ' in-compare' : '');

  const nameEl = document.createElement('div');
  nameEl.className = 'name';
  nameEl.textContent = name || '(未命名)';

  const subEl = document.createElement('div');
  subEl.className = 'sub';
  subEl.textContent = sub;

  btn.append(nameEl, subEl);
  





  btn.addEventListener('click', () => {
    if (!inCompare && typeof onAddToCompare === 'function') {
      onAddToCompare(id, { redraw: false });
    }
    if (typeof onSelect === 'function') onSelect();
  });
  

  if (typeof onRemoveFromCompare === 'function') {
    btn.addEventListener('contextmenu', (e) => {
      if (!inCompare) return;
      e.preventDefault();
      onRemoveFromCompare(id);
    });
  }

  const mv = document.createElement('div');
  mv.className = 'cfg-mv';
  mv.append(
    moveButton({ listEl, id, name, index, delta: -1, total, onMove }),
    moveButton({ listEl, id, name, index, delta: 1, total, onMove })
  );

  row.append(grip, btn, mv);
  return row;
}


function moveButton({ listEl, id, name, index, delta, total, onMove }) {
  const b = document.createElement('button');
  b.type = 'button';
  b.className = 'cfg-mv-btn';
  b.dataset.mv = String(delta);
  b.textContent = delta < 0 ? '↑' : '↓';
  b.disabled = delta < 0 ? index === 0 : index === total - 1;
  const label = delta < 0 ? '上移' : '下移';
  b.title = label;
  b.setAttribute('aria-label', `${label}「${name || '未命名'}」`);

  b.addEventListener('click', () => {
    onMove(id, index + delta);
    
    const again = listEl.querySelector(
      `.cfg-row[data-id="${id}"] .cfg-mv-btn[data-mv="${delta}"]`
    );
    if (again && !again.disabled) again.focus();
  });
  return b;
}




















function bindBlockInputs(container, after) {
  container.addEventListener('input', (e) => {
    if (e.target.classList.contains('rb-request')) {
      
      const node = e.target.closest('.req-block');
      const b = readBlock(node);
      node.querySelector('.rb-sub').textContent = blockSummary(b, b.kind);
    }
    after();
  });
  container.addEventListener('change', (e) => {
    const t = e.target;
    if (t.classList.contains('rb-enable')) {
      
      t.closest('.req-block').classList.toggle('rb-off', !t.checked);
    }
    after();
  });
}

function bindBlockActions({ collect, render }, container) {
  container.addEventListener('click', (e) => {
    const head = e.target.closest('.rb-head');
    if (head && !e.target.closest('.rb-on, .rb-mini')) {
      const node = head.closest('.req-block');
      const open = node.classList.toggle('open');
      blockFold.set(node.dataset.id, open);
      return;
    }

    const btn = e.target.closest('button');
    const node = btn && btn.closest('.req-block');
    if (!btn || !node) return;
    const cfg = collect();
    if (!cfg) return;
    const i = (cfg.fallbacks || []).findIndex((f) => f.id === node.dataset.id);

    if (btn.classList.contains('rb-del') && i >= 0) {
      const item = cfg.fallbacks[i];
      if (item.request.trim() && !confirm(`删掉「后备 ${i + 1}」？此操作不可撤销。`)) return;
      cfg.fallbacks.splice(i, 1);
      blockFold.delete(item.id);
    } else if (btn.classList.contains('rb-up') && i > 0) {
      
      cfg.fallbacks = moveItem(cfg.fallbacks, i, i - 1);
    } else if (btn.classList.contains('rb-down') && i >= 0 && i < cfg.fallbacks.length - 1) {
      cfg.fallbacks = moveItem(cfg.fallbacks, i, i + 1);
    } else {
      return; 
    }

    

    const movedBtn = btn.classList.contains('rb-up') || btn.classList.contains('rb-down');

    render();
    persist();

    if (movedBtn) {
      const again = container.querySelector(
        `.req-block[data-id="${node.dataset.id}"] .rb-${btn.classList.contains('rb-up') ? 'up' : 'down'}`
      );
      if (again) again.focus();
    }
  });
}


function moveConfig(id, to) {
  flushEditor();
  const from = state.configs.findIndex((c) => c.id === id);
  if (from < 0) return false;
  const next = moveItem(state.configs, from, to);
  if (next === state.configs) return false; 
  state.configs = next;
  

  state.settings.slotConfigs = sortByConfigOrder(slotConfigIds());
  renderConfigList();
  persist();
  return true;
}



function dropSpot(listEl, y, itemSel) {
  const rows = [...listEl.querySelectorAll(itemSel)];
  if (!rows.length) return null;
  for (const row of rows) {
    const b = row.getBoundingClientRect();
    if (y < b.bottom) return { row, after: y > b.top + b.height / 2 };
  }
  
  return { row: rows[rows.length - 1], after: true };
}











function bindSortDrag(listEl, applyMove, opts = {}) {
  const ITEM = opts.itemSel || '.cfg-row';
  const GRIP = opts.gripSel || '.cfg-grip';
  const isGrid = !!opts.grid;
  let drag = null; 

  const clearMarks = () => {
    for (const row of listEl.querySelectorAll(ITEM)) {
      row.classList.remove('dragging', 'drop-before', 'drop-after');
    }
  };

  

  const gridSpot = (x, y) => {
    const cards = [...listEl.querySelectorAll(ITEM)];
    if (!cards.length) return null;
    let best = null;
    let bestD = Infinity;
    for (const c of cards) {
      const b = c.getBoundingClientRect();
      
      const d = Math.hypot(x - (b.left + b.width / 2), y - (b.top + b.height / 2));
      if (d < bestD) {
        bestD = d;
        best = { row: c, after: x > b.left + b.width / 2 };
      }
    }
    return best;
  };

  const spotAt = (x, y) => (isGrid ? gridSpot(x, y) : dropSpot(listEl, y, ITEM));

  listEl.addEventListener('pointerdown', (e) => {
    const grip = e.target instanceof Element ? e.target.closest(GRIP) : null;
    if (!grip || e.button !== 0) return;
    e.preventDefault(); 
    drag = {
      id: grip.closest(ITEM).dataset.id,
      pointerId: e.pointerId,
      y0: e.clientY,
      x0: e.clientX,
      y: e.clientY,
      x: e.clientX,
      moved: false
    };
    try {
      grip.setPointerCapture(e.pointerId);
    } catch {
      
    }
  });

  listEl.addEventListener('pointermove', (e) => {
    if (!drag || e.pointerId !== drag.pointerId) return;
    drag.y = e.clientY;
    drag.x = e.clientX;
    
    if (!drag.moved) {
      
      const d = isGrid
        ? Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0)
        : Math.abs(e.clientY - drag.y0);
      if (d < 4) return;
      drag.moved = true;
      listEl.classList.add('is-dragging');
    }

    const spot = spotAt(e.clientX, e.clientY);
    clearMarks();
    if (!spot) return;
    spot.row.classList.add(spot.after ? 'drop-after' : 'drop-before');
    const self = listEl.querySelector(`[data-id="${drag.id}"]`);
    if (self) self.classList.add('dragging');
  });

  const finish = () => {
    if (!drag) return;
    const d = drag;
    drag = null;
    listEl.classList.remove('is-dragging');
    clearMarks();
    if (!d.moved) return; 

    const spot = spotAt(d.x, d.y);
    if (!spot) return;
    const ids = [...listEl.querySelectorAll(ITEM)].map((r) => r.dataset.id);
    const to = dropIndex(ids, d.id, spot.row.dataset.id, spot.after);
    if (to < 0) return;
    applyMove(d.id, to);
  };

  listEl.addEventListener('pointerup', finish);
  
  
  window.addEventListener('pointerup', finish);
  const abort = () => {
    if (!drag) return;
    drag = null;
    listEl.classList.remove('is-dragging');
    clearMarks();
  };
  listEl.addEventListener('pointercancel', abort);
  window.addEventListener('pointercancel', abort);
}



function summarizeUrl(text, empty) {
  const m = String(text || '').match(/https?:\/\/[^\s'"\\]+/);
  if (!m) return empty;
  const url = m[0].replace(/^https?:\/\//, '');
  return url.length > 40 ? url.slice(0, 40) + '…' : url;
}

function selectConfig(id) {
  flushEditor();
  editingId = id;
  state.activeConfigId = id;
  refreshConfigViews();
}



function currentConfig() {
  return state.configs.find((c) => c.id === editingId) || null;
}












const MODE_OPTIONS = [
  { v: 'auto', t: '自动识别' },
  { v: 'sse', t: 'SSE 事件流' },
  { v: 'json', t: '整体 JSON' },
  { v: 'text', t: '纯文本' }
];

function optionsHtml(list, value) {
  return list
    .map((o) => `<option value="${escapeHtml(o.v)}"${o.v === value ? ' selected' : ''}>${escapeHtml(o.t)}</option>`)
    .join('');
}





const CHIPS = [
  { ins: '{{text}}', t: '选中/待翻译的文本' },
  { ins: '{{target}}', t: '设置里的目标语言，原样搬过来（给聊天模型看）' },
  {
    ins: '{{targetCode}}',
    t: '映射成接口要的代码 ZH-HANS / JA，给 DeepL 这类只认代码的接口用。换服务就在请求文本里写一张 #@lang 表改掉（README 有现成的表）'
  },
  { ins: '{{image}}', t: '截图翻译直传模式下的图片（data URL）；普通翻译时是空串' },
  {
    ins: '{{imagePart}}',
    t: '图片那一段（含前导逗号），写在 content 数组最后；没图时是空串。用它就能让一段模板同时翻文字和翻图'
  },
  { ins: '{{url}}', t: '页面地址' },
  { ins: '{{title}}', t: '页面标题' },
  { ins: '{{date}}', t: '今天日期' }
];
const OCR_CHIPS = [
  { ins: '{{image}}', t: '截图的 data URL（OpenAI 兼容接口用这个）' },
  { ins: '{{imageBase64}}', t: '裸 base64（不带 data: 前缀），给要纯 base64 的接口' },
  { ins: '{{imageUrlEncoded}}', t: 'base64 再过一遍 URL 编码（百度这类表单接口要这种）' },
  { ins: '{{apiKey}}', t: '「变量」页签里的 apiKey，和翻译配置共用' }
];


function chipsHtml(list) {
  return `<div class="chips">` + list.map((c) =>
    `<button type="button" class="chip" data-ins="${c.ins}" title="${escapeHtml(c.t)}">` +
    `${escapeHtml(c.ins.slice(2, -2))}</button>`
  ).join('') + '</div>';
}


function adapterLabel(id) {
  const a = ADAPTERS[id];
  return a ? a.label : String(id || '（未知适配器）');
}


function blockSummary(item, kind) {
  if (kind === 'adapter') return T('opt_adapter_prefix', '内置适配器：') + adapterLabel(item.adapter);
  return summarizeUrl(item.request, '（还没写请求模板）');
}





















function templateFieldHtml({ wrapAttrs, boxAttrs, title, value, placeholder, hint, open, hidden, chips, dismiss }) {
  return `
        <details ${wrapAttrs}${hidden ? ' hidden' : ''}${open ? ' open' : ''}>
          <summary>${escapeHtml(title)}</summary>
          <div class="fold-body">
            ${chips ? chipsHtml(chips) : ''}
            <textarea ${boxAttrs} spellcheck="false" wrap="off"
              placeholder="${escapeHtml(placeholder)}">${escapeHtml(value)}</textarea>
            <p class="hint"${dismiss ? ` data-hint="${dismiss}"` : ''}>${hint}</p>
          </div>
        </details>`;
}














function blockHtml(item, idx, lastIdx, opts = {}) {
  const isMain = !!item.main;
  const isAdapter = !!item.adapter;
  const kind = isAdapter ? 'adapter' : 'request';
  const hideReq = isAdapter ? ' hidden' : '';
  const ocr = !!opts.ocr;
  return `
    <div class="req-block" data-id="${escapeHtml(item.id)}" data-adapter="${escapeHtml(item.adapter || '')}">
      <div class="rb-head">
        <label class="rb-on" title="${T('opt_no_rotate', '不勾就不参与轮换（测试也不跑它）')}">
          <input type="checkbox" class="rb-enable"${item.enabled ? ' checked' : ''}>
        </label>
        <span class="rb-tag">${escapeHtml(isMain ? '主请求' : item.name)}</span>
        <span class="rb-sub">${escapeHtml(blockSummary(item, kind))}</span>
        ${item.imageRequest && item.imageRequest.trim() ? `<span class="rb-badge" title="${T('opt_img_badge', '这条填了「图片请求模板」，截图翻译时会走它（图片直传模式）')}">图</span>` : ''}
        <span class="spacer"></span>
        ${isMain ? '' : `
          <button type="button" class="rb-mini rb-up" title="${T('opt_up', '上移（越靠前越先试）')}"${idx <= 1 ? ' disabled' : ''}>↑</button>
          <button type="button" class="rb-mini rb-down" title="${T('opt_down', '下移')}"${idx >= lastIdx ? ' disabled' : ''}>↓</button>
          <button type="button" class="rb-mini rb-del" title="${T('opt_del_fallback', '删掉这条后备请求')}">×</button>`}
        <button type="button" class="rb-fold" title="${T('opt_fold', '折叠 / 展开（点这一行也行）')}">▾</button>
      </div>
      <div class="rb-body">
        ${isAdapter ? `
        <div class="field rb-adapter-field">
          <label>${T('opt_label_adapter', '内置适配器')}</label>
          <p class="rb-adapter-note">${escapeHtml(adapterLabel(item.adapter))}</p>
          <p class="hint">${escapeHtml((ADAPTERS[item.adapter] || {}).hint || '')}</p>
        </div>` : ''}
        ${templateFieldHtml({
          wrapAttrs: 'class="preview tpl-fold rb-only-request"',
          boxAttrs: 'class="rb-request"',
          title: '请求模板',
          value: item.request,
          placeholder: '在这里粘贴 curl，或者写原始 HTTP 报文',
          open: true,
          hidden: isAdapter,
          chips: opts.chips,
          dismiss: ocr ? 'ocr-tpl' : 'cfg-tpl',
          hint: ocr
            ? `除占位符外一字不改地发出去；<b>提示词直接写在请求文本里</b>，不是占位符。
               三个图片占位符的区别见上面那排标签的悬停提示 —— 百度那类表单接口要
               <code>{{imageUrlEncoded}}</code>（base64 里的 <code>+</code> 不转成 <code>%2B</code> 会被当空格）。
               Key 走 <code>{{apiKey}}</code>，别写死在模板里。`
            : `curl 和原始 HTTP 报文都行，除占位符外一字不改地发出去。
               JSON 里不能有裸换行（写 <code>\\n</code>），双引号写 <code>\\"</code>；行首 <code>#</code> 是注释。`
        })}
        ${ocr ? '' : templateFieldHtml({
          wrapAttrs: 'class="preview tpl-fold img-tpl rb-only-request"',
          boxAttrs: 'class="rb-image-request"',
          title: '图片请求模板（可选 · 点开填）',
          value: item.imageRequest,
          placeholder: '留空 = 图片那次也用上面那段模板',
          
          open: !!item.imageRequest.trim(),
          hidden: isAdapter,
          chips: opts.chips,
          dismiss: 'img-tpl',
          hint: `<b>填了这段（主请求或哪条后备都行），这条配置才会出现在 OCR 栏的「图片配置」列表里。</b>
            它管翻图，上面那段继续管划词翻译；留空就回退到上面那段。<br>
            写成多模态的样子，比如：
            <code>{"role":"user","content":[{"type":"image_url","image_url":{"url":"{{image}}"}},{"type":"text","text":"把图里的文字翻成{{target}}，只输出译文"}]}</code><br>
            这段里 <code>{{text}}</code> 是空串 —— 直传时图片本身就是原文。`
        })}
        ${ ''}
        ${ocr ? '' : `<div class="field mode-field rb-only-request"${hideReq}>
          <label>${T('opt_label_mode', '响应格式')}</label>
          <select class="rb-mode">${optionsHtml(MODE_OPTIONS, item.responseMode)}</select>
        </div>`}
        <div class="field rb-only-request"${hideReq}>
          <label>${T('opt_label_path', '响应提取路径（留空自动识别）')}</label>
          <input class="rb-path" type="text" spellcheck="false" placeholder="choices[0].message.content" value="${escapeHtml(item.path)}">
          <p class="hint" data-hint="${ocr ? 'ocr-path' : 'cfg-path'}">${ocr
            ? '点号 + 下标，例如百度的 <code>words_result</code>（一行一个对象，会按行拼成一段）。留空时依次尝试各家常见的返回结构。'
            : '点号 + 下标，例如 <code>data.translations[0].translatedText</code>。留空时会依次尝试各家常见的返回结构。'}</p>
        </div>
      </div>
    </div>`;
}



function foldOpen(id) {
  return blockFold.get(id) === true;
}




function renderBlocksInto(host, owner, opts) {
  const all = allRequests(owner);
  const tplSel = opts.ocr ? '.rb-request' : '.rb-request, .rb-image-request';
  host.innerHTML = all.map((it, i) => blockHtml(it, i, all.length - 1, opts)).join('');
  

  host.querySelectorAll('.req-block').forEach((node) => {
    node.classList.toggle('open', foldOpen(node.dataset.id));
    node.classList.toggle('rb-off', !node.querySelector('.rb-enable').checked);
  });
  
  host.querySelectorAll(tplSel).forEach(bindTemplateBox);
  
  applyHintHides();
}


function renderBlocks(cfg) {
  renderBlocksInto(els.blocks, cfg, { chips: CHIPS });
}


function renderOcrBlocks(p) {
  renderBlocksInto(els.ocrBlocks, p, { chips: OCR_CHIPS, ocr: true });
}











function bindChips(container) {
  container.addEventListener('click', (e) => {
    const chip = e.target.closest('.chip');
    if (!chip) return;
    const block = chip.closest('.req-block');
    if (!block) return;
    const box = (focusedTemplate && block.contains(focusedTemplate))
      ? focusedTemplate
      : block.querySelector('.rb-request');
    if (!box) return;
    block.classList.add('open');
    blockFold.set(block.dataset.id, true);
    insertAtCursor(box, chip.dataset.ins);
  });
}




function readBlock(node) {
  const adapter = node.dataset.adapter || '';
  const val = (sel) => {
    const el = node.querySelector(sel);
    return el ? el.value : '';
  };
  return {
    id: node.dataset.id,
    kind: adapter ? 'adapter' : 'request',
    adapter,
    request: val('.rb-request'),
    imageRequest: val('.rb-image-request'),
    path: val('.rb-path').trim(),
    responseMode: val('.rb-mode') || 'auto',
    enabled: node.querySelector('.rb-enable').checked
  };
}

function renderEditor() {
  const cfg = currentConfig();

  if (!cfg) {
    els.editor.hidden = true;
    els.emptyHint.hidden = false;
    return;
  }

  els.editor.hidden = false;
  els.emptyHint.hidden = true;

  els.name.value = cfg.name || '';
  els.testResult.hidden = true;
  els.testResult.innerHTML = '';
  renderBlocks(cfg);

  updatePreview();
  setSaveStatus('');
}


function collectEditor() {
  const cfg = currentConfig();
  if (!cfg) return null;
  cfg.name = els.name.value.trim() || '未命名配置';

  for (const node of els.blocks.querySelectorAll('.req-block')) {
    const isMain = node.dataset.id === cfg.id;
    const item = isMain ? cfg : (cfg.fallbacks || []).find((f) => f.id === node.dataset.id);
    if (!item) continue;
    const b = readBlock(node);
    
    const adapter = b.adapter;
    if (isMain) {
      cfg.adapter = adapter;
      cfg.request = b.request;
      cfg.imageRequest = b.imageRequest;
      cfg.path = b.path;
      cfg.responseMode = b.responseMode;
      cfg.mainEnabled = b.enabled;
    } else {
      item.adapter = adapter;
      item.request = b.request;
      item.imageRequest = b.imageRequest;
      item.path = b.path;
      item.responseMode = b.responseMode;
      item.enabled = b.enabled;
      
    }
  }
  return cfg;
}

function bindConfigList() {
  
  bindSortDrag(els.cfgList, moveConfig);
  bindSortDrag(els.imgcfgList, moveImageConfig);

  $('#btn-new').addEventListener('click', () => {
    flushEditor();
    const cfg = {
      id: uid(),
      name: '新配置',
      note: '',
      adapter: '',
      request:
        'curl https://example.com/v1/chat/completions \\\n' +
        '  -H "Content-Type: application/json" \\\n' +
        '  -H "Authorization: Bearer {{apiKey}}" \\\n' +
        "  -d '{\n" +
        '  "model": "your-model",\n' +
        '  "messages": [{"role": "user", "content": "{{text}}"}],\n' +
        '  "stream": true\n' +
        "}'",
      path: '',
      responseMode: 'auto',
      imageRequest: '',
      mainEnabled: true,
      fallbacks: []
    };
    state.configs.push(cfg);
    editingId = cfg.id;
    state.activeConfigId = cfg.id;
    refreshConfigViews();
    els.name.focus();
    els.name.select();
  });
}

function bindEditor() {
  els.name.addEventListener('input', () => {
    collectEditor();
    updatePreview();
    scheduleSave();
    
    renderConfigList();
  });

  
  bindBlockInputs(els.blocks, () => {
    collectEditor();
    updatePreview();
    scheduleSave();
  });

  
  bindBlockActions({
    collect: collectEditor,
    render: () => {
      renderBlocks(currentConfig());
      renderConfigList();
      updatePreview();
    }
  }, els.blocks);

  els.btnAddFallback.addEventListener('click', () => {
    const cfg = collectEditor();
    if (!cfg) return;
    

    const item = {
      id: uid(),
      enabled: true,
      adapter: cfg.adapter,
      request: cfg.request,
      imageRequest: cfg.imageRequest,
      path: cfg.path,
      responseMode: cfg.responseMode
    };
    if (!Array.isArray(cfg.fallbacks)) cfg.fallbacks = [];
    cfg.fallbacks.push(item);
    blockFold.set(item.id, true);   
    renderBlocks(cfg);
    renderConfigList();
    updatePreview();
    persist();
    
    
    const box = els.blocks.querySelector(`.req-block[data-id="${item.id}"] .rb-request`);
    if (box) {
      box.focus();
      box.setSelectionRange(box.value.length, box.value.length);
      box.scrollIntoView({ block: 'nearest' });
    }
  });

  



  bindChips(els.blocks);
  bindChips(els.ocrBlocks);

$('#btn-duplicate').addEventListener('click', () => {
    const cfg = currentConfig();
    if (!cfg) return;
    const copy = {
      ...cfg,
      id: uid(),
      name: cfg.name + ' 副本',
      
      fallbacks: (cfg.fallbacks || []).map((f) => ({ ...f, id: uid() }))
    };
    const idx = state.configs.findIndex((c) => c.id === cfg.id);
    state.configs.splice(idx + 1, 0, copy);
    editingId = copy.id;
    state.activeConfigId = copy.id;
    refreshConfigViews();
  });

  $('#btn-delete').addEventListener('click', () => {
    const cfg = currentConfig();
    if (!cfg) return;
    if (state.configs.length === 1) {
      alert('至少要留一条配置。');
      return;
    }
    if (!confirm(`确定删除「${cfg.name || '未命名'}」？此操作不可撤销。`)) return;

    const idx = state.configs.findIndex((c) => c.id === cfg.id);
    state.configs.splice(idx, 1);
    editingId = state.configs[Math.max(0, idx - 1)].id;
    state.activeConfigId = editingId;
    
    state.settings.slotConfigs = sortByConfigOrder(
      slotConfigIds().filter((x) => x !== cfg.id)
    );
    refreshConfigViews();
  });

  $('#btn-test').addEventListener('click', runTest);
  els.testText.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') runTest();
  });
}

function insertAtCursor(textarea, text) {
  

  const fold = textarea.closest('details.tpl-fold');
  if (fold) fold.open = true;

  const start = textarea.selectionStart;
  const end = textarea.selectionEnd;
  const value = textarea.value;
  textarea.value = value.slice(0, start) + text + value.slice(end);
  textarea.selectionStart = textarea.selectionEnd = start + text.length;
  textarea.focus();
  


  textarea.dispatchEvent(new Event('input', { bubbles: true }));
}


function bindTemplateBox(el) {
  el.addEventListener('focus', () => {
    focusedTemplate = el;
  });
  el.addEventListener('keydown', (e) => {
    if (e.key !== 'Tab') return;
    e.preventDefault();
    insertAtCursor(el, '  ');
  });
}



let previewTimer = null;






function formatPreview(req, notes = []) {
  const lines = [];
  lines.push('方法：' + (req.method || 'GET'));
  lines.push('地址：' + (req.url || '(没有 URL)'));
  lines.push('');
  lines.push('请求头：');
  for (const [k, v] of Object.entries(req.headers || {})) lines.push('  ' + k + ': ' + v);
  lines.push('');
  lines.push('—— 实际会发出的请求体 ——');
  lines.push('');
  lines.push(req.body == null || req.body === '' ? '(这条请求没有请求体)' : String(req.body));
  if (notes.length) {
    lines.push('');
    lines.push('—— 备注 ——');
    for (const n of notes) lines.push('· ' + n);
  }
  return lines.join('\n');
}








function previewBlock(b, vars, ivars) {
  if (b.kind === 'adapter') {
    const a = ADAPTERS[b.adapter];
    return a
      ? T('opt_adapter_prefix', '内置适配器：') + a.label + '\n\n' + a.hint + '\n\n' + T('opt_adapter_note', '这条请求不走请求模板，翻译流程由扩展内置的代码完成。')
      : '(没有可用的内置适配器)';
  }
  if (!b.request.trim()) return '(请求模板为空)';

  const info = previewRequest(b.request, vars, b.path);
  const notes = [`写法：${info.request.style === 'raw' ? '原始 HTTP 报文' : 'curl'}（自动识别）`];
  

  const mkey = modelVarFor(b.request, vars);
  const models = modelCandidates(b.request, vars);
  if (models.length > 1) {
    notes.push(
      `model 轮换：${mkey} 填了 ${models.length} 个候选，上面摊的是第一个（${models[0]}）；` +
      '「测试」和真翻译都会从它开始逐个试'
    );
  }
  if (info.missing.length) {
    notes.push('未定义的变量（按空串替换）：' + info.missing.map((m) => '{{' + m + '}}').join(' '));
  }
  for (const p of info.problems) notes.push('问题：' + p);
  for (const w of info.warnings || []) notes.push('提示：' + w);
  for (const n of info.notes) notes.push('修正：' + n);

  let out = formatPreview(info.request, notes);

  
  const imgTpl = b.imageRequest.trim();
  if (imgTpl) {
    const iinfo = previewRequest(imgTpl, ivars, b.path);
    const inotes = [];
    if (iinfo.missing.length) {
      inotes.push('未定义的变量（按空串替换）：' + iinfo.missing.map((m) => '{{' + m + '}}').join(' '));
    }
    for (const p of iinfo.problems) inotes.push('问题：' + p);
    for (const w of iinfo.warnings || []) inotes.push('提示：' + w);
    for (const n of iinfo.notes) inotes.push('修正：' + n);
    out += '\n\n══════ 图片请求模板（截图直传那一次用它）══════\n\n' + formatPreview(iinfo.request, inotes);
  }
  return out;
}


function blockTitle(i) {
  return i === 0 ? '主请求' : `后备 ${i}`;
}

function updatePreview() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    const nodes = [...els.blocks.querySelectorAll('.req-block')];
    if (!nodes.length) {
      els.preview.textContent = '(没有请求)';
      return;
    }

    
    let vars;
    let ivars;
    try {
      vars = buildVars(state, 'Hello, world! 这是一段示例文本。', {
        url: 'https://example.com/page',
        title: '示例页面'
      });
      ivars = buildVars(state, '', {
        url: 'https://example.com/page',
        title: '示例页面',
        image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg=='
      });
    } catch {
      vars = { text: 'Hello, world!' };
      ivars = { image: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==' };
    }

    const parts = [];
    nodes.forEach((node, i) => {
      const b = readBlock(node);
      parts.push(`━━━━━━ ${blockTitle(i)}${b.enabled ? '' : '（已勾掉，不参与轮换）'} ━━━━━━`);
      parts.push(previewBlock(b, vars, ivars));
    });
    els.preview.textContent = parts.join('\n\n');
  }, 180);
}















async function runTest() {
  

  if ($('#btn-test').disabled) return;
  collectEditor();
  await persist(false);

  const cfg = currentConfig();
  if (!cfg) return;

  const text = els.testText.value.trim() || 'Hello, world!';
  const chain = requestChain(cfg);
  const btn = $('#btn-test');
  btn.disabled = true;
  btn.textContent = '发送中…';

  let vars;
  try {
    vars = buildVars(state, text, { url: location.href, title: 'RequestTranslate 测试' });
  } catch {
    vars = { text };
  }

  

  const plan = chain.map((item) => {
    const requestText = requestTemplateFor(item, {});
    const mkey = modelVarFor(requestText, vars);
    const models = modelCandidates(requestText, vars);
    return { item, requestText, mkey, attempts: models.length ? models : [null] };
  });
  const total = plan.reduce((n, p) => n + p.attempts.length, 0);
  const rotating = total > plan.length;

  els.testResult.hidden = false;
  els.testResult.innerHTML = '';
  const head = document.createElement('div');
  head.className = 'result-head test-head';
  

  head.innerHTML =
    `<span class="badge">链上共 ${chain.length} 条请求</span>` +
    (rotating ? `<span class="badge">model 逐个试，最多发 ${total} 次</span>` : '');
  els.testResult.appendChild(head);

  let got = false;
  let sent = 0;
  for (let i = 0; i < plan.length && !got; i += 1) {
    const { item, requestText, mkey, attempts } = plan[i];

    for (let j = 0; j < attempts.length; j += 1) {
      const model = attempts[j];
      let result;
      try {
        result = await runRequest({
          requestText,
          adapter: item.adapter,
          
          vars: model == null ? vars : { ...vars, [mkey]: model },
          path: item.path,
          responseMode: item.responseMode
        });
      } catch (err) {
        result = { ok: false, status: 0, ms: 0, text: '', error: String(err && err.message), warnings: [], raw: '' };
      }
      sent += 1;
      els.testResult.insertAdjacentHTML(
        'beforeend',
        testItemHtml(item, result, { model: attempts.length > 1 ? model : '' })
      );

      if (result && result.text) {
        

        got = true;
        const left = total - sent;
        const at = attempts.length > 1 ? `第 ${i + 1} 条第 ${j + 1} 个 model 拿到译文` : `第 ${i + 1} 条拿到译文`;
        const tail = left ? (rotating ? `，还有 ${left} 次没发` : `，后面 ${left} 条没跑`) : '';
        head.insertAdjacentHTML('beforeend', `<span class="badge ok">${at}${tail}</span>`);
        break;
      }
    }
  }
  if (!got) {
    head.insertAdjacentHTML(
      'beforeend',
      `<span class="badge err">${rotating ? `${total} 次都没拿到译文` : `${chain.length} 条都没拿到译文`}</span>`
    );
  }

  btn.disabled = false;
  btn.textContent = '发送';
}





function requestBlockHtml(req) {
  if (!req) return '';
  const text =
    `${req.method} ${req.url}\n` +
    Object.entries(req.headers || {}).map(([k, v]) => `${k}: ${v}`).join('\n') +
    (req.body ? '\n\n' + truncateText(req.body, 2000) : '');
  return `<div class="row"><div class="row-title">${T('opt_row_actual', '实际请求')}</div><pre>${escapeHtml(text)}</pre></div>`;
}









function shortError(err) {
  const raw = String(err || '').trim();
  const m = /"message"\s*:\s*"((?:[^"\\]|\\.)*)"/.exec(raw);
  if (m) {
    try {
      return String(JSON.parse('"' + m[1] + '"')).trim();
    } catch {
      return m[1].replace(/\\(.)/g, '$1').trim();
    }
  }
  return raw.replace(/\s+/g, ' ').slice(0, 120);
}













function resultBlockHtml({ head = '', body = '', fold, why = '' }) {
  const headHtml = head + (fold && why ? `<span class="why">${escapeHtml(why)}</span>` : '');
  if (!fold) {
    return `<div class="result-head">${headHtml}</div><div class="result-body">${body}</div>`;
  }
  return `<details class="test-fold"><summary class="result-head">${headHtml}</summary>` +
    `<div class="result-body">${body}</div></details>`;
}



function testItemHtml(item, r, opts = {}) {
  const rows = [];

  const badges = [
    `<span class="badge ${r.ok ? 'ok' : 'err'}">HTTP ${r.status || '失败'}</span>`,
    `<span class="badge">${r.ms} ms</span>`
  ];
  
  if (opts.model) badges.unshift(`<span class="badge">${escapeHtml(opts.model)}</span>`);
  if (r.usedPath) badges.push(`<span class="badge">${escapeHtml(r.usedPath)}</span>`);
  for (const w of r.warnings || []) badges.push(`<span class="badge warn">${escapeHtml(w)}</span>`);
  if (r.missingVars && r.missingVars.length) {
    badges.push(`<span class="badge warn">未填变量 ${r.missingVars.map(escapeHtml).join(', ')}</span>`);
  }

  if (r.error) {
    rows.push(
      `<div class="row"><div class="row-title">${T('opt_row_error', '错误')}</div><pre class="err-text">${escapeHtml(r.error)}</pre></div>`
    );
  }

  if (r.text) {
    rows.push(
      `<div class="row"><div class="row-title">${T('opt_row_text', '提取到的译文')}</div><pre class="translated">${escapeHtml(r.text)}</pre></div>`
    );
  }

  if (r.request) rows.push(requestBlockHtml(r.request));

  if (r.raw) {
    const raw = truncateText(r.raw, 8000);
    rows.push(
      `<div class="row"><div class="row-title">${T('opt_row_raw', '原始响应')}</div><pre>${escapeHtml(raw)}</pre></div>`
    );
  }

  const title = item.main ? '主请求' : escapeHtml(item.name);
  return `<div class="result test-item">${resultBlockHtml({
    head: `<span class="badge">${title}</span>${badges.join('')}`,
    body: rows.join(''),
    fold: !r.text,
    why: shortError(r.error)
  })}</div>`;
}










function growTextarea(el) {
  if (!el.offsetParent) return;
  el.style.height = 'auto';
  el.style.height = el.scrollHeight + 'px';
}


function growVarValues() {
  els.varsBody.querySelectorAll('textarea[data-kind="value"]').forEach((el) => {
    
    if (el.closest('.var-row.editing')) growTextarea(el);
  });
}

function bindVars() {
  $('#btn-add-var').addEventListener('click', () => {
    
    state.vars.push({ name: '', value: '' });
    editingVarIdx = state.vars.length - 1;
    renderVars();
    persist();
    const input = els.varsBody.querySelector('.var-row.editing input[data-kind="name"]');
    if (input) input.focus();
  });

  



  bindSortDrag(
    els.varsBody,
    (id, to) => {
      const from = Number(id);
      const next = moveItem(state.vars, from, to);
      if (next === state.vars) return; 
      state.vars = next;
      
      
      
      
      if (editingVarIdx === from) editingVarIdx = to;
      else if (editingVarIdx > from && editingVarIdx <= to) editingVarIdx -= 1;
      else if (editingVarIdx >= to && editingVarIdx < from) editingVarIdx += 1;
      renderVars();
      persist();
      updatePreview();
    },
    { itemSel: '.var-row', gripSel: '.var-grip', grid: true }
  );
}


let editingVarIdx = -1;





function varValueSummary(v) {
  if (isSecretVar(v.name)) return '••••••';
  const lines = String(v.value || '').split('\n').filter((l) => l.trim());
  if (lines.length === 0) return '';
  const first = lines[0].length > 42 ? lines[0].slice(0, 42) + '…' : lines[0];
  return lines.length > 1 ? `${first} +${lines.length - 1}` : first;
}





function renderVars() {
  els.varsBody.innerHTML = '';

  state.vars.forEach((v, idx) => {
    const row = document.createElement('div');
    row.className = 'var-row' + (idx === editingVarIdx ? ' editing' : '');
    

    row.dataset.id = String(idx);

    if (idx !== editingVarIdx) {
      
      row.title = '点开编辑';

      

      const grip = document.createElement('span');
      grip.className = 'var-grip';
      grip.innerHTML = GRIP_SVG;
      grip.title = '按住拖动，调整顺序';
      grip.setAttribute('aria-hidden', 'true'); 
      row.appendChild(grip);

      const nameEl = document.createElement('span');
      nameEl.className = 'var-name';
      nameEl.textContent = v.name || '(未命名)';
      if (isSecretVar(v.name)) nameEl.classList.add('is-key');

      const subEl = document.createElement('span');
      subEl.className = 'var-sub';
      subEl.textContent = varValueSummary(v) || '空';
      
      row.title = `${v.name || '(未命名)'}\n${varValueSummary(v) || '空'}\n\n点开编辑`;

      

      const main = document.createElement('div');
      main.className = 'var-main';
      main.append(nameEl, subEl);

      const eye = document.createElement('button');
      eye.type = 'button';
      eye.className = 'row-eye' + (isSecretVar(v.name) ? '' : ' off');
      eye.innerHTML = EYE_OFF_SVG;
      eye.title = '点开编辑';
      eye.addEventListener('click', () => {
        editingVarIdx = idx;
        renderVars();
      });

      const del = document.createElement('button');
      del.className = 'row-del';
      del.textContent = '✕';
      del.title = '删除';
      del.addEventListener('click', () => {
        if (editingVarIdx === idx) editingVarIdx = -1;
        else if (editingVarIdx > idx) editingVarIdx -= 1;
        state.vars.splice(idx, 1);
        renderVars();
        persist();
        updatePreview();
      });

      row.append(main);
      const acts = document.createElement('div');
      acts.className = 'var-acts';
      acts.append(eye, del);
      row.appendChild(acts);
      row.addEventListener('click', (e) => {
        
        if (e.target.closest('button, .var-grip')) return;
        editingVarIdx = idx;
        renderVars();
      });
      els.varsBody.appendChild(row);
      return;
    }

    
    const nameInput = document.createElement('input');
    nameInput.type = 'text';
    nameInput.value = v.name;
    nameInput.placeholder = 'apiKey';
    nameInput.dataset.kind = 'name';
    nameInput.spellcheck = false;
    nameInput.addEventListener('input', () => {
      state.vars[idx].name = nameInput.value.replace(/[^\w.-]/g, '');
      if (nameInput.value !== state.vars[idx].name) nameInput.value = state.vars[idx].name;
      

      applyMask(isSecretVar(state.vars[idx].name));
      syncEye();
      scheduleSave();
      updatePreview();
    });

    

    const valueInput = document.createElement('textarea');
    valueInput.rows = 1;
    valueInput.value = v.value;
    valueInput.placeholder = '值（一行一个）';
    valueInput.spellcheck = false;
    valueInput.autocomplete = 'off';
    valueInput.dataset.kind = 'value';
    valueInput.autofocus = v.name && true; 
    const autoGrow = () => growTextarea(valueInput);
    


    const applyMask = (on) => valueInput.classList.toggle('masked', on);
    applyMask(isSecretVar(v.name));
    valueInput.addEventListener('input', () => {
      state.vars[idx].value = valueInput.value;
      autoGrow();
      scheduleSave();
      updatePreview();
    });

    const eye = document.createElement('button');
    eye.type = 'button';
    eye.className = 'row-eye';
    
    const syncEye = () => {
      const masked = valueInput.classList.contains('masked');
      eye.innerHTML = masked ? EYE_SVG : EYE_OFF_SVG;
      eye.classList.toggle('on', !masked);
      eye.title = masked ? '显示' : '隐藏';
      eye.setAttribute('aria-label', eye.title);
    };
    eye.addEventListener('click', () => {
      valueInput.classList.toggle('masked');
      syncEye();
    });
    syncEye();

    
    requestAnimationFrame(autoGrow);

    const del = document.createElement('button');
    del.className = 'row-del';
    del.textContent = '✕';
    del.title = '删除';
    del.addEventListener('click', () => {
      editingVarIdx = -1;
      state.vars.splice(idx, 1);
      renderVars();
      persist();
      updatePreview();
    });

    

    const foldBtn = document.createElement('button');
    foldBtn.type = 'button';
    foldBtn.className = 'row-fold';
    foldBtn.textContent = '收起';
    foldBtn.title = '收起这一条（点名字再摊开）';
    foldBtn.addEventListener('click', () => {
      editingVarIdx = -1;
      renderVars();
    });

    const nameRow = document.createElement('div');
    nameRow.className = 'var-edit-name';
    nameRow.append(nameInput);
    const valRow = document.createElement('div');
    valRow.className = 'var-edit-val';
    valRow.append(valueInput, eye);
    const bar = document.createElement('div');
    bar.className = 'var-edit-bar';
    bar.append(foldBtn, del);
    row.append(nameRow, valRow, bar);
    els.varsBody.appendChild(row);

    
    if (v.name) valueInput.focus();
    else nameInput.focus();
  });

  els.builtinBody.innerHTML = Object.entries(BUILTIN_VAR_HINTS)
    .map(([k, hint]) => `<tr><td>{{${escapeHtml(k)}}}</td><td>${escapeHtml(hint)}</td></tr>`)
    .join('');
}




function currentOcrProvider() {
  return state.ocr.providers.find((p) => p.id === editingOcrId) || null;
}


function summarizeOcr(p) {
  return summarizeUrl(p.request, '(还没填请求模板)');
}




function renderOcrList() {
  els.ocrList.innerHTML = '';

  state.ocr.providers.forEach((p, idx) => {
    els.ocrList.appendChild(sortableRow({
      id: p.id,
      name: p.name,
      sub: summarizeOcr(p),
      active: p.id === state.ocr.activeId,
      index: idx,
      total: state.ocr.providers.length,
      listEl: els.ocrList,
      onSelect: () => selectOcr(p.id),
      onMove: moveOcrProvider
    }));
  });
}


function moveOcrProvider(id, to) {
  const from = state.ocr.providers.findIndex((p) => p.id === id);
  if (from < 0) return false;
  const next = moveItem(state.ocr.providers, from, to);
  if (next === state.ocr.providers) return false; 
  state.ocr.providers = next;
  renderOcrList();
  persist();
  return true;
}












function imageConfigs() {
  return state.configs.filter(canTranslateImage);
}




function imageItem(c) {
  if (!c) return null;
  return requestChain(c).find((r) => String(r.imageRequest || '').trim()) || null;
}



function imageTestConfig() {
  const list = imageConfigs();
  if (!list.length) return null;
  return list.find((c) => c.id === state.ocr.imageConfigId) || list[0];
}

function renderImageConfigList() {
  const list = imageConfigs();
  els.imgcfgList.innerHTML = '';

  
  if (!list.length) {
    const empty = document.createElement('p');
    empty.className = 'hint';
    empty.innerHTML =
      '还没有任何配置填过「图片请求模板」。<br>' +
      '去<b>「配置」</b>栏挑一条能看图的那个模型，把「图片请求模板」填上，它就会出现在这里。' +
      '<br>（填在主请求上或任意一条后备上都认。）';
    els.imgcfgList.appendChild(empty);
    if (state.ocr.imageConfigId) {
      state.ocr.imageConfigId = '';
      scheduleSave();
    }
    return;
  }

  
  
  if (!list.some((c) => c.id === state.ocr.imageConfigId)) {
    state.ocr.imageConfigId = list[0].id;
    scheduleSave();
  }

  for (let i = 0; i < list.length; i++) {
    const c = list[i];
    
    
    const it = imageItem(c);
    els.imgcfgList.appendChild(sortableRow({
      id: c.id,
      name: c.name,
      sub: it ? summarizeUrl(it.imageRequest, '(空)') : '(空)',
      active: c.id === state.ocr.imageConfigId,
      inCompare: imgSlotConfigIds().includes(c.id),
      index: i,
      total: list.length,
      listEl: els.imgcfgList,
      onSelect: () => {
        state.ocr.imageConfigId = c.id;
        panelTouched.add('imageConfigId'); 
        renderImageConfigList();
        
        renderOcrPreview();
        els.ocrTestResult.hidden = true;
        persist(false);
      },
      onMove: moveImageConfig,
      

      onAddToCompare: toggleImgSlotConfig,
      onRemoveFromCompare: (cid) => toggleImgSlotConfig(cid, { force: false })
    }));
  }
}










function moveImageConfig(id, to) {
  flushEditor();
  const vis = imageConfigs().map((c) => c.id);
  const from = vis.indexOf(id);
  if (from < 0) return false;
  const next = moveVisibleItem(state.configs, vis, from, to);
  if (next === state.configs) return false; 
  state.configs = next;
  
  state.settings.slotConfigs = sortByConfigOrder(slotConfigIds());
  renderConfigList();
  renderImageConfigList();
  persist();
  return true;
}


function renderOcrDisabled() {
  const off = !!state.ocr.disabled;
  els.oDisabled.checked = off;

  



  els.ocrList.hidden = off;
  els.imgcfgList.hidden = !off;
  els.ocrListTitle.textContent = off ? '图片配置' : 'OCR 配置';
  
  els.btnOcrNew.hidden = off;
  els.imgcfgFoot.hidden = !off;
  els.imgcfgHint.hidden = !off;
  els.ocrEditor.classList.toggle('is-imgcfg', off);
  
  if (off) renderImageConfigList();

  


  const imgForTest = off ? imageTestConfig() : null;
  els.ocrTestBtn.disabled = off && !imgForTest;
  els.ocrTestBtn.title = off
    ? (imgForTest
        ? '用的是左边选中的那条「图片配置」的图片请求模板'
        : '还没有配置填过「图片请求模板」—— 去「配置」栏给能看图的那条填上')
    : '';
  els.oTestLabel.textContent = off ? '测试图片配置' : '测试';
  els.ocrTestHint.hidden = off;
  els.imgcfgTestHint.hidden = !off;
  

  const imgOn = imgForTest ? imageItem(imgForTest) : null;
  const onLabel = imgOn && !imgOn.main ? ` · 走后备「${imgOn.name || '未命名'}」` : '';
  els.oPreviewSummary.textContent = off
    ? `这次会发出去的请求（示例图${onLabel} · Key 已打码）`
    : '这次会发出去的请求（Key 已打码）';
}

function renderOcrEditor() {
  renderOcrDisabled();
  const p = currentOcrProvider();

  

  if (!p && !state.ocr.disabled) {
    els.ocrEditor.hidden = true;
    els.ocrEmpty.hidden = false;
    return;
  }

  els.ocrEditor.hidden = false;
  els.ocrEmpty.hidden = true;
  if (!p) {
    renderOcrPreview(); 
    return;
  }

  els.oName.value = p.name || '';
  
  els.oNote.textContent = p.note || '';
  els.oNote.title = p.note || '';
  
  renderOcrBlocks(p);

  
  els.ocrTestResult.hidden = true;

  renderOcrPreview();

  
  els.btnOcrDelete.disabled = state.ocr.providers.length <= 1;
}






const OCR_SAMPLE_IMAGE = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==';

function renderOcrPreview() {
  

  const off = !!state.ocr.disabled;
  const p = off
    ? (() => {
        
        const it = imageItem(imageTestConfig());
        return it ? { request: it.imageRequest, responsePath: it.path } : null;
      })()
    : currentOcrProvider();
  if (!p) {
    els.oPreview.textContent = off
      ? '左边还没有能翻图的配置。去「配置」栏给能看图的那条填上「图片请求模板」，这里就会摊出来。'
      : '';
    return;
  }

  
  
  let vars;
  try {
    vars = buildVars(state, '', { image: OCR_SAMPLE_IMAGE });
  } catch {
    vars = {};
  }

  

  const chain = off
    ? [{ request: p.request, path: p.responsePath }]
    : requestChain({ ...p, path: p.responsePath || '' });

  const parts = chain.map((item) => {
    const req = previewOcrRequest(item, OCR_SAMPLE_IMAGE, vars);
    const notes = [...(req.warnings || [])];
    if (req.style) notes.unshift(`写法：${req.style === 'raw' ? '原始 HTTP 报文' : 'curl'}（自动识别）`);
    if (/{{image(Base64|UrlEncoded)?}}/.test(String(item.request || ''))) {
      notes.push('上面 {{image}} 的位置是一张假的示例图，真截图是一整段 data URL；「测试」跑完后的「实际请求」里是那一份真的');
    }
    const head = chain.length > 1 ? `—— ${item.main ? '主请求' : (item.name || '后备')} ——` : '';
    return head ? head + '\n' + formatPreview(req, notes) : formatPreview(req, notes);
  });

  els.oPreview.textContent = parts.join('\n\n');
}



function collectOcrEditor() {
  const p = currentOcrProvider();
  if (!p) return null;
  p.name = els.oName.value.trim() || '未命名供应商';

  for (const node of els.ocrBlocks.querySelectorAll('.req-block')) {
    const isMain = node.dataset.id === p.id;
    const item = isMain ? p : (p.fallbacks || []).find((f) => f.id === node.dataset.id);
    if (!item) continue;
    const b = readBlock(node);
    if (isMain) {
      p.request = b.request;
      p.responsePath = b.path;
      p.mainEnabled = b.enabled;
    } else {
      item.request = b.request;
      item.path = b.path;
      item.enabled = b.enabled;
    }
  }
  return p;
}

function selectOcr(id) {
  collectOcrEditor();
  editingOcrId = id;
  state.ocr.activeId = id;
  renderOcrList();
  renderOcrEditor();
  persist(false);
}

function bindOcr() {
  

  bindSortDrag(els.ocrList, moveOcrProvider);

  els.oName.addEventListener('input', () => {
    const p = currentOcrProvider();
    if (!p) return;
    p.name = els.oName.value;
    
    renderOcrList();
    scheduleSave();
  });

  
  
  bindBlockInputs(els.ocrBlocks, () => {
    collectOcrEditor();
    renderOcrList();
    renderOcrPreview();
    scheduleSave();
  });

  
  bindBlockActions({
    collect: collectOcrEditor,
    render: () => {
      renderOcrBlocks(currentOcrProvider());
      renderOcrList();
      renderOcrPreview();
    }
  }, els.ocrBlocks);

  els.btnOcrAddFallback.addEventListener('click', () => {
    const p = collectOcrEditor();
    if (!p) return;
    p.fallbacks = p.fallbacks || [];
    p.fallbacks.push(normalizeOcrItem({ request: p.request }));
    renderOcrBlocks(p);
    renderOcrList();
    renderOcrPreview();
    persist();
  });

  els.oDisabled.addEventListener('input', () => {
    state.ocr.disabled = els.oDisabled.checked;
    renderOcrDisabled();
    
    renderOcrPreview();
    els.ocrTestResult.hidden = true;
    scheduleSave();
  });

  els.btnOcrNew.addEventListener('click', () => {
    collectOcrEditor();
    
    
    
    
    const p = normalizeOcrProvider({
      name: '新供应商',
      note: '',
      request: OCR_PROVIDERS[0].request
    });
    state.ocr.providers.push(p);
    editingOcrId = state.ocr.activeId = p.id;
    renderOcrList();
    renderOcrEditor();
    
    els.oName.focus();
    els.oName.select();
    scheduleSave();
  });

  els.btnOcrDuplicate.addEventListener('click', () => {
    const src = currentOcrProvider();
    if (!src) return;
    collectOcrEditor();
    const copy = normalizeOcrProvider({
      ...src,
      id: '',
      name: (src.name || '未命名') + ' 副本'
    });
    state.ocr.providers.push(copy);
    editingOcrId = state.ocr.activeId = copy.id;
    renderOcrList();
    renderOcrEditor();
    scheduleSave();
  });

  els.btnOcrDelete.addEventListener('click', () => {
    const p = currentOcrProvider();
    if (!p || state.ocr.providers.length <= 1) return;
    if (!confirm(`删除 OCR 供应商「${p.name}」？`)) return;

    const idx = state.ocr.providers.findIndex((x) => x.id === p.id);
    state.ocr.providers.splice(idx, 1);
    
    if (BUILTIN_OCR_IDS.includes(p.id) && !state.ocr.hidden.includes(p.id)) {
      state.ocr.hidden.push(p.id);
    }

    const next = state.ocr.providers[Math.min(idx, state.ocr.providers.length - 1)];
    editingOcrId = state.ocr.activeId = next.id;
    renderOcrList();
    renderOcrEditor();
    persist();
  });

  els.ocrTestBtn.addEventListener('click', runOcrTest);

  els.ocrTestImg.addEventListener('change', () => {
    const f = els.ocrTestImg.files && els.ocrTestImg.files[0];
    ocrTestFile = f || null;
    els.ocrTestResult.hidden = true; 
  });
}















function formatBytes(n) {
  const b = Math.max(0, Number(n) || 0);
  if (b < 1024) return b + ' B';
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1024 / 1024).toFixed(1) + ' MB';
}

function truncateText(s, n) {
  const t = String(s ?? '');
  return t.length > n ? t.slice(0, n) + '\n\n…（已截断，共 ' + t.length + ' 字）' : t;
}


async function clipboardImage() {
  if (!navigator.clipboard || !navigator.clipboard.read) {
    throw new Error(CLIPBOARD_UNAVAILABLE_MESSAGE);
  }

  let items;
  try {
    items = await navigator.clipboard.read();
  } catch (err) {
    throw new Error(CLIPBOARD_UNAVAILABLE_MESSAGE + '（' + ((err && err.message) || err) + '）');
  }

  for (const item of items || []) {
    const type = pickImageMime(item && item.types);
    if (!type) continue;
    const blob = await item.getType(type);
    const bytes = new Uint8Array(await blob.arrayBuffer());
    return { dataUrl: toDataUrl(bytes, type), bytes: bytes.length, source: '剪切板' };
  }

  throw new Error(NO_IMAGE_MESSAGE);
}

async function fileImage(file) {
  const bytes = new Uint8Array(await file.arrayBuffer());
  return { dataUrl: toDataUrl(bytes, file.type), bytes: bytes.length, source: '本地图片 ' + file.name };
}

async function runOcrTest() {
  



  const off = !!state.ocr.disabled;
  let target = null;
  if (off) {
    target = imageTestConfig();
  } else {
    collectOcrEditor();
    await persist(false);
    target = currentOcrProvider();
  }
  if (!target) return;

  

  const item = off ? imageItem(target) : null;
  const label = item && !item.main ? `${target.name} · ${item.name}` : target.name;

  const btn = els.ocrTestBtn;
  
  btn.disabled = true;
  btn.textContent = '测试中…';
  const box = els.ocrTestResult;
  box.hidden = false;

  let shot = null;
  try {
    shot = ocrTestFile ? await fileImage(ocrTestFile) : await clipboardImage();
  } catch (err) {
    btn.disabled = false; 
    btn.textContent = '测试';
    box.innerHTML =
      '<div class="result-head"><span class="badge err">没拿到图片</span>' +
      `<span class="badge">${escapeHtml(label)}</span></div>` +
      '<div class="result-body"><div class="row"><div class="row-title">原因</div>' +
      `<pre class="err-text">${escapeHtml((err && err.message) || err)}</pre></div></div>`;
    return;
  }

  const srcLabel = shot.source + ' · ' + formatBytes(shot.bytes);
  btn.disabled = true;
  btn.textContent = off ? '翻译中…' : '识别中…';
  box.innerHTML =
    '<div class="result-head"><span class="badge">请求中…</span>' +
    `<span class="badge">${escapeHtml(label)}</span>` +
    `<span class="badge">${escapeHtml(srcLabel)}</span></div>`;

  let r = null;
  let err = null;
  try {
    const vars = buildVars(state, '', { image: shot.dataUrl });
    r = off
      ? await runImageTranslate({ config: item || target, dataUrl: shot.dataUrl, vars })
      : await runOcr({ provider: target, dataUrl: shot.dataUrl, vars });
  } catch (e) {
    err = e;
  }

  btn.disabled = false;
  btn.textContent = '测试';
  renderOcrTestResult({
    
    name: label + (r && r.from && r.from !== '主请求' ? ` · ${r.from}` : ''),
    srcLabel,
    r,
    err,
    textTitle: off ? '译文' : '识别到的文字'
  });
}

function renderOcrTestResult({ name, srcLabel, r, err, textTitle = '识别到的文字' }) {
  const status = err ? (err.status || '失败') : r.status;
  const ms = err ? err.ms : r.ms;

  const badges = [`<span class="badge ${err ? 'err' : 'ok'}">HTTP ${escapeHtml(String(status))}</span>`];
  if (typeof ms === 'number') badges.push(`<span class="badge">${ms} ms</span>`);
  badges.push(`<span class="badge">${escapeHtml(name)}</span>`);
  badges.push(`<span class="badge">${escapeHtml(srcLabel)}</span>`);

  const rows = [];
  if (err) {
    rows.push(
      `<div class="row"><div class="row-title">${T('opt_row_error', '错误')}</div><pre class="err-text">${escapeHtml(
        (err && err.message) || String(err)
      )}</pre></div>`
    );
  }
  if (r && r.text) {
    rows.push(
      `<div class="row"><div class="row-title">${escapeHtml(textTitle)}</div><pre class="translated">${escapeHtml(
        r.text
      )}</pre></div>`
    );
  }

  
  rows.push(requestBlockHtml((err && err.request) || (r && r.request)));

  const raw = (err && err.raw) || (r && r.raw);
  if (raw) {
    rows.push(
      `<div class="row"><div class="row-title">${T('opt_row_raw', '原始响应')}</div><pre>${escapeHtml(
        truncateText(raw, 8000)
      )}</pre></div>`
    );
  }

  

  els.ocrTestResult.innerHTML = resultBlockHtml({
    head: badges.join(''),
    body: rows.join(''),
    fold: !(r && r.text),
    why: shortError((err && err.message) || '请求成功但没认出任何文字')
  });
}


















const SETTING_MAP = [
  {
    sel: '#s-trigger', key: 'trigger', kind: 'value',
    load: (v) => v, save: (el) => el.value
  },
  {
    sel: '#s-ctx', key: 'contextMenu', kind: 'checked',
    load: (v) => !!v, save: (el) => el.checked
  },
  {
    
    sel: '#s-ocrmenu', key: 'ocrMenu', kind: 'checked',
    load: (v) => v !== false, save: (el) => el.checked
  },
  {
    sel: '#s-shotmenu', key: 'shotMenu', kind: 'checked',
    load: (v) => v !== false, save: (el) => el.checked
  },
  {
    
    
    sel: '#s-max', key: 'maxChars', kind: 'number',
    load: (v) => v, save: (el) => Number(el.value) || 8000
  },
  {
    sel: '#s-framebridge', key: 'frameBridge', kind: 'checked',
    load: (v) => v !== false, save: (el) => !!el.checked
  },
  {
    sel: '#s-slots', key: 'panelSlots', kind: 'number',
    load: (v) => String(clampSlots(v)),
    save: (el) => clampSlots(el.value),
    
    after: () => syncSlotInsertRow()
  },
  {
    sel: '#s-slotinsert', key: 'slotInsert', kind: 'value',
    load: (v) => (v === 'head' ? 'head' : 'tail'),
    save: (el) => (el.value === 'head' ? 'head' : 'tail')
  },
  {
    sel: '#s-historymax', key: 'historyMax', kind: 'number',
    load: (v) => v, save: (el) => Math.max(0, Math.round(Number(el.value) || 0))
  },
  {
    sel: '#s-width', key: 'panelWidth', kind: 'number',
    load: (v) => v, save: (el) => Number(el.value) || 0
  },
  {
    sel: '#s-height', key: 'panelHeight', kind: 'number',
    load: (v) => v, save: (el) => Number(el.value) || 0
  },
  {
    
    sel: '#s-maxh', key: 'panelMaxHeight', kind: 'number',
    load: (v) => v ?? 46, save: (el) => Number(el.value) || 0
  },
  {
    sel: '#s-font', key: 'fontSize', kind: 'number',
    load: (v) => v, save: (el) => Number(el.value) || 0
  },
  {
    sel: '#s-theme', key: 'theme', kind: 'value',
    load: (v) => v, save: (el) => el.value,
    after: () => applyTheme()
  },

  {
    sel: '#s-showsrc', key: 'showOriginal', kind: 'checked',
    load: (v) => !!v, save: (el) => el.checked
  },
  {
    sel: '#s-panelcss', key: 'panelCss', kind: 'value',
    load: (v) => String(v == null ? '' : v), save: (el) => el.value
  },
  {
    sel: '#s-trigsize', key: 'triggerSize', kind: 'number',
    load: (v) => clampTriggerSize(v), save: (el) => Number(el.value) || 0,
    
    after: () => renderPreview()
  },
  {
    
    sel: '#s-trigidle', key: 'triggerIdleSec', kind: 'number',
    load: (v) => v ?? 5, save: (el) => Number(el.value) || 0
  },
  {
    
    sel: '#s-trigleave', key: 'triggerLeaveSec', kind: 'number',
    load: (v) => v ?? 0.5, save: (el) => Number(el.value) || 0
  },
  {
    sel: '#s-trigsvg', key: 'triggerSvg', kind: 'value',
    load: (v) => v || '', save: (el) => el.value,
    
    after: () => {
      updateTriggerSvgMsg();
      renderPreview();
      renderTriggerStyles();
    }
  }
];















function syncGroupCounts() {
  for (const group of document.querySelectorAll('.set-group')) {
    const n = group.querySelectorAll('.set-group-body .setting').length;
    group.querySelector('summary').dataset.count = n ? n + ' 项' : '';
  }
}























const PV_SAMPLE_SRC =
  "原文：This is a paragraph of source text that was selected on a web page, used here to show what the source area looks like.";
const PV_SAMPLE_OUT =
  "译文：这是选中的那段原文的译文示例。字号、行距、换行、滚动条都按真面板来 —— " +
  "因为它就是真面板。调整上面的宽度 / 字号 / 高度，这里会跟着变，和网页上的效果一致。" +
  "\n\n第二段：多写几行，好让结果区真的出现滚动条，这样「结果区最大高度」也能看出区别。" +
  "\n\n第三段：如果内容不够长，面板高度设多大都撑不满，看着就像没生效 —— 所以这段故意写长。";

let pvBuilt = false;

let pvNeedsRender = false;

function renderPanelPreview() {
  const host = document.getElementById("panel-preview");
  if (!host || !state) return;
  const s = state.settings || {};

  


  if (!pvBuilt) {
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = PANEL_CSS;
    shadow.appendChild(style);

    const panel = document.createElement("div");
    panel.className = "rt-panel";
    panel.id = "rt-panel";
    panel.innerHTML = RTPanelCore.shellHtml();   
      "</div></div>" +
      '<div class="rt-body"><div class="rt-src"></div><div class="rt-out"></div></div>' +
      '<div class="rt-foot"><span class="rt-msg">HTTP 200 · 0.8s</span></div>' +
      '<div class="rt-diag" hidden></div>';
    shadow.appendChild(panel);

    

    panel.style.position = "fixed";
    panel.style.left = "auto";
    panel.style.right = "32px";
    panel.style.top = "80px";
    panel.style.display = "flex";
    panel.style.zIndex = "2147483647";

    
    pvBindDrag(panel);

    
    panel
      .querySelector('[data-act="close"]')
      .addEventListener("click", () => setPvVisible(false));

    
    panel.querySelector('[data-act="src"]').addEventListener("click", () => {
      const src = host.shadowRoot.querySelector(".rt-src");
      if (src) src.classList.toggle("hidden");
    });

    pvBuilt = true;
  }

  const panel = host.shadowRoot.querySelector(".rt-panel");
  const srcEl = host.shadowRoot.querySelector(".rt-src");
  const outEl = host.shadowRoot.querySelector(".rt-out");

  
  {
    const sh = host.shadowRoot;
    let ucss = sh.querySelector("#rt-user-css");
    const cssText = String(s.panelCss == null ? "" : s.panelCss);
    if (!cssText.trim()) {
      if (ucss) ucss.remove();
    } else {
      if (!ucss) {
        ucss = document.createElement("style");
        ucss.id = "rt-user-css";
        sh.appendChild(ucss);
      }
      ucss.textContent = cssText;
    }
  }

  


  const w = Math.min(1600, Math.max(280, Number(s.panelWidth) || 460));
  const fs = Math.min(48, Math.max(11, Number(s.fontSize) || 20));
  const h = Math.min(2400, Math.max(0, Number(s.panelHeight) || 0));
  const mh = Math.min(100, Math.max(0, Number(s.panelMaxHeight) || 46));

  panel.style.width = w + "px";
  panel.style.maxWidth = "";
  panel.style.transform = "";
  panel.style.setProperty("--rt-fs", fs + "px");
  panel.style.setProperty("--rt-fs-sm", (fs * 0.92).toFixed(2) + "px");
  panel.style.setProperty("--rt-fs-xs", (fs * 0.85).toFixed(2) + "px");

  panel.style.maxHeight = h > 0 ? h + "px" : "";
  panel.classList.toggle("fixed-h", h > 0);
  panel.classList.toggle("no-max-h", mh === 0);
  panel.style.setProperty("--rt-max-h", mh + "vh");

  
  const pvLight = (() => {
    const t = s.theme || "auto";
    if (t === "light") return true;
    if (t === "dark") return false;
    return !(window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches);
  })();
  panel.classList.toggle("light", pvLight);
  panel.dataset.rtTheme = pvLight ? "light" : "dark";

  

  panel.classList.add("show");
  

  {
    const eye = host.shadowRoot.querySelector('[data-act="src"]');
    if (eye) eye.classList.toggle("on", s.showOriginal !== false);
  }

  

  {
    const diag = host.shadowRoot.querySelector(".rt-diag");
    const more = host.shadowRoot.querySelector(".rt-more");
    if (diag) {
      RTPanelCore.renderDiag(diag, [
        { k: "首字", v: "1.02 s", hint: "第一个译文分片出现的时间" },
        { k: "总耗时", v: "1.15 s" },
        { k: "响应格式", v: "SSE" },
        { k: "分片", v: "4" },
        { k: "响应大小", v: "1.8 KB" },
        { k: "命中路径", v: "choices[0].delta.content" },
        { k: "模型", v: "deepseek-v4-flash-0731" }
      ]);
      diag.hidden = false;
    }
    if (more) more.hidden = false;
  }
  {
    const dot = host.shadowRoot.querySelector(".rt-dot");
    if (dot) dot.classList.add("ok");
  }

  

  {
    const cfgSel = host.shadowRoot.querySelector(".rt-cfg");
    const langSel = host.shadowRoot.querySelector(".rt-lang");
    const cfgs = (state.configs || []).filter((c) => c && c.name);
    if (cfgSel) {
      const list = cfgs.length ? cfgs : [{ id: "", name: "（没有配置）" }];
      cfgSel.textContent = "";
      for (const c of list) {
        const o = document.createElement("option");
        o.value = c.id || "";
        o.textContent = c.name;
        cfgSel.appendChild(o);
      }
      const wantId = s.activeConfigId || (list[0] && list[0].id) || "";
      cfgSel.value = wantId;
      const cur = list.find((c) => c.id === wantId) || list[0];
      cfgSel.title = "翻译接口：" + cur.name;
    }
    if (langSel) {
      

      const lang = s.targetLang || "简体中文";
      const cands = TARGET_PRESETS.slice();
      if (!cands.includes(lang)) cands.push(lang);
      langSel.textContent = "";
      for (const v of cands) {
        const o = document.createElement("option");
        o.value = v;
        o.textContent = v;
        langSel.appendChild(o);
      }
      langSel.value = lang;
      langSel.title = "目标语言：" + lang;
    }
  }

  srcEl.textContent = PV_SAMPLE_SRC;
  


  outEl.classList.remove("empty");
  

  outEl.innerHTML = RTPanelCore.slotsHtml([
    { configId: "pv-1", name: "配置甲", state: "done", text: PV_SAMPLE_OUT, error: "", statusText: "" },
    { configId: "pv-2", name: "配置乙", state: "fail", text: "", error: "译文：这一条故意标成失败，用来看 err 态的颜色。", statusText: "" }
  ], {});
  srcEl.classList.toggle("hidden", !(s.showOriginal !== false));
}


function pvBindDrag(panel) {
  const head = panel.querySelector("[data-drag]");
  if (!head) return;
  let dragging = false;
  let sx = 0;
  let sy = 0;
  let px = 0;
  let py = 0;

  head.addEventListener("mousedown", (e) => {
    if (e.target.closest(".rt-btn") || e.target.closest(".rt-cfg") || e.target.closest(".rt-lang")) return;
    
    const r = panel.getBoundingClientRect();
    panel.style.left = r.left + "px";
    panel.style.right = "auto";
    panel.style.top = r.top + "px";
    dragging = true;
    sx = e.clientX;
    sy = e.clientY;
    px = r.left;
    py = r.top;
    e.preventDefault();
  });

  window.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const k = 1 / pvZoom();
    const w = panel.offsetWidth * k;
    const h = panel.offsetHeight * k;
    const edge = 12 * k;
    let nx = px + (e.clientX - sx) * k;
    let ny = py + (e.clientY - sy) * k;
    nx = Math.min(Math.max(nx, edge), Math.max(edge, window.innerWidth - w - edge));
    ny = Math.min(Math.max(ny, edge), Math.max(edge, window.innerHeight - h - edge));
    panel.style.left = nx + "px";
    panel.style.top = ny + "px";
  });

  window.addEventListener("mouseup", () => {
    dragging = false;
  });
}


function pvZoom() {
  return 1;
}


function setPvVisible(on) {
  const host = document.getElementById("panel-preview");
  const btn = document.getElementById("btn-pv-open");
  if (!host) return;
  host.hidden = !on;
  if (btn) btn.textContent = on ? "收起面板" : "显示面板";
  if (on) renderPanelPreview();
}

function syncSlotInsertRow() {
  const row = $('#row-slotinsert');
  if (!row) return;
  const n = clampSlots(state.settings.panelSlots);
  row.hidden = n <= 1;
}

function renderSettings() {
  for (const row of SETTING_MAP) {
    const el = $(row.sel);
    const v = row.load(state.settings[row.key]);
    if (row.kind === 'checked') el.checked = v;
    else el.value = v;
  }
  syncSlotInsertRow();

  
  renderTargetLang();
  renderTriggerStyles();
  updateTriggerSvgMsg();
  renderPreview();
  renderHistory();
  applyTheme();
}









function renderHistory() {
  const list = $('#history-list');
  if (!list) return;
  const max = Math.max(0, Number(state.settings.historyMax) || 0);
  const all = (Array.isArray(state.history) ? state.history : []).slice(0, max);

  
  const q = String($('#history-search')?.value || '').trim().toLowerCase();
  const items = q
    ? all.filter((h) =>
        [h.src, h.dst, h.configName, h.lang]
          .some((v) => String(v || '').toLowerCase().includes(q))
      )
    : all;

  if (!all.length) {
    list.innerHTML = '<p class="hint">' + T('opt_hist_empty', '还没有记录（或上面把条数设成了 0）。') + '</p>';
    return;
  }
  if (!items.length) {
    list.innerHTML = '<p class="hint">' + T('opt_hist_nomatch_a', '没有匹配「') + escapeHtml(q) + T('opt_hist_nomatch_b', '」的记录。') + '</p>';
    return;
  }

  const fmt = (ts) => {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, '0');
    return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };

  

  const redoHint = (h) => {
    const now = getConfig(state, state.activeConfigId);
    const was = h.configName || '';
    return now && was && now.name !== was
      ? `用「${now.name}」重翻这条（当时用的是「${was}」）`
      : '用当前配置重翻这条原文';
  };

  list.innerHTML = items
    .map((h, i) => {
      const idx = all.indexOf(h);
      return (
        '<div class="history-item" data-hi="' + idx + '">' +
        `<div class="h-meta">${escapeHtml(fmt(h.ts))} · ${escapeHtml(h.configName || '')} · ${escapeHtml(h.lang || '')}</div>` +
        `<div class="h-src">${escapeHtml(h.src)}</div>` +
        `<div class="h-dst">${escapeHtml(h.dst)}</div>` +
        `<div class="h-acts">` +
        `<button type="button" class="ghost h-act" data-act="copy" title="复制这条译文">复制译文</button>` +
        `<button type="button" class="ghost h-act" data-act="redo" title="${escapeHtml(redoHint(h))}">重翻</button>` +
        `</div>` +
        '</div>'
      );
    })
    .join('');
}






function flashButton(btn, text, restore, ms = 1400) {
  const old = restore == null ? btn.textContent : restore;
  btn.textContent = text;
  setTimeout(() => {
    btn.textContent = old;
  }, ms);
}

async function onHistoryAction(e) {
  const btn = e.target.closest('.h-act');
  if (!btn) return;
  const item = btn.closest('.history-item');
  if (!item) return;
  const idx = Number(item.dataset.hi);
  const h = (state.history || [])[idx];
  if (!h) return;

  if (btn.dataset.act === 'copy') {
    try {
      await navigator.clipboard.writeText(String(h.dst || ''));
      flashButton(btn, '已复制', '复制译文');
    } catch {
      flashButton(btn, '复制失败', '复制译文');
    }
    return;
  }

  if (btn.dataset.act === 'redo') {
    const cfg = getConfig(state, state.activeConfigId);
    if (!cfg) return;
    const oldText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '翻译中…';
    try {
      const vars = buildVars(state, String(h.src || ''), {});
      const r = await runRequest({
        requestText: requestTemplateFor(cfg, {}),
        adapter: cfg.adapter,
        vars,
        path: cfg.path,
        responseMode: cfg.responseMode,
      });
      if (r && r.text) {
        
        h.dst = String(r.text).slice(0, 5000);
        h.configName = cfg.name;
        h.ts = Date.now();
        await saveState(state);
        renderHistory();
        return;
      }
      flashButton(btn, '失败：' + String((r && r.error) || '没有译文').slice(0, 24), oldText, 2600);
    } catch (err) {
      flashButton(btn, '失败：' + String(err && err.message || err).slice(0, 24), oldText, 2600);
    } finally {
      btn.disabled = false;
      if (btn.textContent !== oldText) btn.textContent = oldText;
    }
  }
}


function renderTriggerStyles() {
  
  
  const cur = getTriggerStyle(state.settings.triggerStyle).id;
  
  
  const customSvg = parseTriggerSvg(state.settings.triggerSvg).svg;
  els.trigStyles.innerHTML = TRIGGER_STYLES.map((s) => {
    const icon = s.id === 'custom' ? customSvg : (s.svg || escapeHtml(s.text || ''));
    return (
      '<button type="button" class="trig-card' + (s.id === cur ? ' on' : '') +
      '" data-style="' + s.id + '" title="' + escapeHtml(s.hint) + '">' +
      '<span class="trig-prev' + (s.round ? ' round' : '') + (s.bare ? ' bare' : '') + '">' +
      icon + '</span>' +
      '<span>' + escapeHtml(s.name) + '</span>' +
      '</button>'
    );
  }).join('');
}


function updateTriggerSvgMsg() {
  if (!els.trigSvgMsg) return;
  const raw = els.trigSvg.value.trim();
  const style = getTriggerStyle(state.settings.triggerStyle);
  if (!raw) {
    
    
    if (style.id === 'custom') {
      els.trigSvgMsg.hidden = false;
      els.trigSvgMsg.className = 'trig-svg-msg warn';
      els.trigSvgMsg.textContent =
        '「自定义」还没填图标 —— 上面的卡片先空着，页面上的按钮用一个示例图标占位；' +
        '粘一段自己的 SVG 进来，两边都会换成它。';
    } else {
      els.trigSvgMsg.hidden = true;
      els.trigSvgMsg.textContent = '';
    }
    return;
  }
  const { svg, reason } = parseTriggerSvg(raw);
  els.trigSvgMsg.hidden = false;
  els.trigSvgMsg.className = 'trig-svg-msg' + (svg ? ' ok' : ' bad');
  els.trigSvgMsg.textContent = svg
    ? '这段用上了'
    : '这段没用上 —— ' + reason + '。改好之前按钮还是显示上面的预设。';
}



let previewRoot = null;

function ensurePreviewRoot() {
  if (previewRoot) return previewRoot;
  if (!els.trigPreview) return null;
  previewRoot = els.trigPreview.attachShadow({ mode: 'open' });
  previewRoot.innerHTML =
    '<style>' + TRIGGER_CSS + '</style>' +
    
    '<style>.rt-trigger { position: relative; display: flex; }</style>' +
    '<div class="rt-trigger"><span class="rt-ico"></span></div>';
  return previewRoot;
}

function renderPreview() {
  const root = ensurePreviewRoot();
  if (!root || !state) return;

  const s = getTriggerStyle(state.settings.triggerStyle);
  const el = root.querySelector('.rt-trigger');
  const light = document.documentElement.dataset.theme === 'light';
  const size = Math.min(72, clampTriggerSize(state.settings.triggerSize));

  el.className = 'rt-trigger s-' + s.id + (light ? ' light' : '');
  el.style.setProperty('--rt-tr-size', size + 'px');
  el.style.setProperty('--rt-tr-radius', s.round ? (size * 0.29).toFixed(2) + 'px' : '50%');
  el.style.setProperty('--rt-tr-font', (size * 0.47).toFixed(2) + 'px');
  
  
  
  const custom = parseTriggerSvg(state.settings.triggerSvg).svg;
  const fallback = s.id === 'custom' ? TRIGGER_SVG_SAMPLE : escapeHtml(s.text || '');
  root.querySelector('.rt-ico').innerHTML = custom || s.svg || fallback;
}


function applyTheme() {
  const t = (state && state.settings && state.settings.theme) || 'auto';
  let dark = true;
  if (t === 'light') dark = false;
  else if (t === 'auto') {
    const q = window.matchMedia ? window.matchMedia('(prefers-color-scheme: light)') : null;
    dark = q ? !q.matches : true;
  }
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';

  renderPreview(); 
}


function bindSettings() {
  
  fillTargetLangOptions();
  bindTargetLang();

  



  if (chrome.commands && chrome.commands.getAll) {
    const NAMES = {
      'translate-selection': '翻译选中文字',
      'shot-translate': '框选截图翻译',
      'ocr-clipboard': '翻译剪切板中的截图'
    };
    const render = () => {
      chrome.commands.getAll((list) => {
        const rows = Object.entries(NAMES).map(([name, label]) => {
          const cur = (list.find((c) => c.name === name) || {}).shortcut;
          return `${label}：${cur || '未设置'}`;
        });
        $('#hotkey-list').textContent = rows.join('　｜　');
      });
    };
    render();
    $('#btn-hotkey-open').addEventListener('click', () => {
      
      const url = /^edge/i.test(navigator.userAgent)
        ? 'edge://extensions/shortcuts'
        : 'chrome://extensions/shortcuts';
      chrome.tabs.create({ url });
      
      chrome.windows.getCurrent((w) => {
        if (w && typeof w.id === 'number') {
          chrome.windows.onFocusChanged.addListener(function onFocus(wid) {
            if (wid === w.id) {
              chrome.windows.onFocusChanged.removeListener(onFocus);
              render();
            }
          });
        }
      });
    });
  }

  
  const histList = $('#history-list');
  if (histList) histList.addEventListener('click', onHistoryAction);
  
  const histSearch = $('#history-search');
  if (histSearch) histSearch.addEventListener('input', () => renderHistory());
  
  for (const row of SETTING_MAP) {
    const el = $(row.sel);
    el.addEventListener('input', () => {
      state.settings[row.key] = row.save(el);
      
      if (PANEL_OWNED_SETTING_KEYS.includes(row.key)) panelTouched.add(row.key);
      scheduleSave();
      if (row.after) row.after();
      

      if (PREVIEW_KEYS.has(row.key)) renderPanelPreview();
    });
  }

  


  const PANEL_CSS_WARM = [
    '/* 护眼暖色（参照 Gruvbox Dark 的暖褐基调；对比度已验过：正文 11.2、次要 6.7）',
    '   只覆盖颜色变量，不动布局 —— 想微调就改这里的值 */',
    '#rt-panel {',
    '  --rt-bg: #181713;',
    '  --rt-bg-head: #1f1e19;',
    '  --rt-bg-sub: #1b1a16;',
    '  --rt-bg-diag: #151410;',
    '  --rt-border: #332f27;',
    '  --rt-border-soft: #2a2721;',
    '  --rt-slot-line: #453f34;',
    '  --rt-hover: #282520;',
    '  --rt-scroll: #3b372e;',
    '  --rt-accent: #b8863b;',
    '  --rt-accent-soft: #2a2118;',
    '  --rt-accent-text: #d9a95a;',
    '}',
  ].join('\n');

  const setPanelCss = (value) => {
    els.panelCss.value = value;
    els.panelCss.dispatchEvent(new Event('input', { bubbles: true }));
  };
  els.btnPanelCssWarm.addEventListener('click', () => setPanelCss(PANEL_CSS_WARM));

  
  els.btnPvOpen.addEventListener('click', () => {
    setPvVisible(document.getElementById('panel-preview').hidden);
  });
  els.btnPanelCssClear.addEventListener('click', () => setPanelCss(''));

  els.trigStyles.addEventListener('click', (e) => {
    const card = e.target.closest('.trig-card');
    if (!card) return;
    state.settings.triggerStyle = card.dataset.style;
    renderTriggerStyles();
    
    updateTriggerSvgMsg();
    renderPreview();
    scheduleSave();
  });

  
  const setTriggerSvg = (value) => {
    els.trigSvg.value = value;
    els.trigSvg.dispatchEvent(new Event('input', { bubbles: true }));
  };
  els.btnTrigSvgDemo.addEventListener('click', () => setTriggerSvg(TRIGGER_SVG_SAMPLE));
  els.btnTrigSvgClear.addEventListener('click', () => setTriggerSvg(''));

  

  const restoreHints = $('#btn-restore-hints');
  restoreHints.addEventListener('click', () => {
    state.settings.hiddenHints = [];
    persist();
    for (const el of document.querySelectorAll('[data-hint]')) el.classList.remove('hint-off');
    syncRestoreHints();
    setSaveStatus('已放回全部说明');
  });

  
  $('#btn-clear-history').addEventListener('click', async () => {
    if (!confirm('清空全部翻译记录？不可恢复。')) return;
    state.history = [];
    await persist();
    renderHistory();
    setSaveStatus('已清空翻译记录');
  });

  $('#btn-reset').addEventListener('click', async () => {
    if (!confirm('会删掉你所有自定义配置，恢复成内置的那几条。确定？')) return;
    await chrome.storage.local.remove('state');
    state = await loadState();
    editingId = state.activeConfigId;
    editingOcrId = state.ocr.activeId;
    

    editingVarIdx = -1;
    blockFold.clear();
    renderConfigList();
    renderEditor();
    renderOcrList();
    renderOcrEditor();
    renderVars();
    renderSettings();
    setSaveStatus('已恢复默认');
  });
}












function pickImportConfigs(parsed, exportedAt) {
  return new Promise((resolve) => {
    const dlg = $('#import-dialog');
    const list = $('#import-list');
    const allBox = $('#import-all');
    const mergeBox = $('#import-merge');
    const errEl = $('#import-err');
    const noteEl = $('#import-note');
    if (!dlg || !list) { resolve(null); return; }

    const mine = new Set(state.configs.map((c) => c.name));
    const when = exportedAt ? `导出于 ${exportedAt.slice(0, 16).replace('T', ' ')}` : '';
    noteEl.textContent = `文件里有 ${parsed.configs.length} 条配置${when ? '，' + when : ''}。勾选要导入的：`;
    errEl.textContent = '';
    errEl.classList.remove('is-err');
    mergeBox.checked = false;

    

    list.innerHTML = parsed.configs.map((c, i) => {
      const dup = mine.has(c.name) ? '<span class="imp-sub">同名，导入后会覆盖现有的这条</span>' : '';
      const host = String((c.request || '').split('\n')[0] || '').trim().slice(0, 60);
      return ('<label class="imp-row">' +
        `<input type="checkbox" data-ci="${i}" checked>` +
        `<span><span class="imp-name">${escapeHtml(c.name || '(未命名)')}</span>` +
        (host ? '<span class="imp-sub">' + escapeHtml(host) + '</span>' : '') +
        dup +
        '</span>' +
        '</label>');
    }).join('');
    allBox.checked = true;

    const boxes = () => [...list.querySelectorAll('input[data-ci]')];
    const checkedCount = () => boxes().filter((b) => b.checked).length;

    const onAll = () => {
      const want = allBox.checked;
      for (const b of boxes()) b.checked = want;
    };
    const onOne = () => {
      

      allBox.checked = checkedCount() === boxes().length;
    };
    allBox.addEventListener('change', onAll);
    list.addEventListener('change', onOne);

    const done = (ok) => {
      allBox.removeEventListener('change', onAll);
      list.removeEventListener('change', onOne);
      $('#import-ok').removeEventListener('click', okYes);
      $('#import-cancel').removeEventListener('click', okNo);
      dlg.hidden = true;
      resolve(ok);
    };

    function okYes() {
      const picked = boxes()
        .map((b, i) => (b.checked ? parsed.configs[Number(b.dataset.ci)] : null))
        .filter(Boolean);
      if (!picked.length) {
        errEl.textContent = '至少勾一条';
        errEl.classList.add('is-err');
        return;
      }
      done({ configs: picked, merge: mergeBox.checked });
    }
    function okNo() { done(null); }

    $('#import-ok').addEventListener('click', okYes);
    $('#import-cancel').addEventListener('click', okNo);
    dlg.hidden = false;
  });
}


function askPassphrase({ title, note, twice }) {
  return new Promise((resolve) => {
    const dlg = els.passDialog;
    const input = $('#pass-input');
    const again = $('#pass-again');
    const noteEl = $('#pass-note');
    const btnOk = $('#pass-ok');
    const btnCancel = $('#pass-cancel');

    $('#pass-title').textContent = title;
    noteEl.textContent = note || '';
    noteEl.classList.remove('is-err');
    input.value = '';
    again.value = '';
    again.hidden = !twice;
    dlg.hidden = false;
    input.focus();

    const done = async () => {
      const a = input.value;
      if (twice && a !== again.value) {
        noteEl.textContent = '两次输入的不一致，再试一次';
        noteEl.classList.add('is-err');
        return;
      }
      if (!a) {
        noteEl.textContent = '口令不能是空的';
        noteEl.classList.add('is-err');
        return;
      }
      cleanup();
      resolve(a);
    };
    const cancel = () => {
      cleanup();
      resolve(null);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') cancel();
      if (e.key === 'Enter') done();
    };
    const cleanup = () => {
      dlg.hidden = true;
      btnOk.removeEventListener('click', done);
      btnCancel.removeEventListener('click', cancel);
      document.removeEventListener('keydown', onKey);
    };
    btnOk.addEventListener('click', done);
    btnCancel.addEventListener('click', cancel);
    document.addEventListener('keydown', onKey);
  });
}

function downloadJson(text) {
  const blob = new Blob([text], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  a.download = `request-translate-config-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}







async function bindUiLang() {
  const sel = $('#s-ui-lang');
  const btn = $('#btn-ui-lang');
  const status = $('#ui-lang-status');
  if (!sel || !btn) return;
  const api = window.RTI18n;
  if (!api || !api.fetchIndex) return;

  const say = (text, isErr) => {
    if (!status) return;
    status.textContent = text;
    status.classList.toggle('is-err', !!isErr);
  };

  
  const cur = api.currentPack && api.currentPack();
  sel.value = cur && cur.lang ? cur.lang : '';

  




  let indexLoaded = false;
  const loadIndexOnce = async () => {
    if (indexLoaded) return true;
    try {
      const index = await api.fetchIndex();
      for (const [code, meta] of Object.entries(index)) {
        if (!meta || !meta.file) continue;
        const opt = document.createElement('option');
        opt.value = code;
        const pct = typeof meta.progress === 'number' ? Math.round(meta.progress * 100) : 100;
        opt.textContent = (meta.name || code) + (pct < 100 ? ' (' + pct + '%)' : '');
        sel.appendChild(opt);
      }
      indexLoaded = true;
      return true;
    } catch {
      say(T('opt_ui_lang_offline', '取不到语言清单（离线或被挡），先用内置中文。'), true);
      return false;
    }
  };

  btn.addEventListener('click', async () => {
    

    if (!indexLoaded) {
      btn.disabled = true;
      say(T('opt_ui_lang_dl', '正在下载…'));
      const got = await loadIndexOnce();
      btn.disabled = false;
      if (!got) return;
      if (Object.keys(sel.options).length > 1) {
        say(T('opt_ui_lang_pick', '清单已取到，选一种语言再点一次。'));
        return;
      }
    }
    const code = sel.value;
    if (!code) {
      await api.clearPack();
      say(T('opt_ui_lang_reset', '已切回内置中文，正在重载…'));
      setTimeout(() => location.reload(), 600);
      return;
    }
    btn.disabled = true;
    say(T('opt_ui_lang_dl', '正在下载…'));
    const r = await api.downloadPack(code);
    btn.disabled = false;
    if (r.ok) {
      
      say(T('opt_ui_lang_ok_pre', '已装好') + ' ' + r.count + ' ' + T('opt_ui_lang_ok_post', '条，正在重载…'));
      setTimeout(() => location.reload(), 600);
    } else {
      
      say(T('opt_ui_lang_fail', '下载失败：') + r.why, true);
    }
  });
}
function bindImportExport() {
  $('#btn-export').addEventListener('click', async () => {
    
    collectEditor();
    const plain = exportState(state);

    if (els.chkEncrypt.checked) {
      const pass = await askPassphrase({
        title: '设置导出口令',
        note: '口令不保存在任何地方 —— 丢了它，这份文件就解不开了。',
        twice: true
      });
      if (!pass) return; 
      const wrapped = await encryptExport(plain, pass);
      downloadJson(wrapped);
      setSaveStatus('已导出（加密） · ' + state.configs.length + ' 条配置');
      return;
    }

    downloadJson(plain);
    setSaveStatus('已导出 ' + state.configs.length + ' 条配置');
  });

  


  $('#btn-export-share').addEventListener('click', () => {
    collectEditor();
    const shared = structuredClone(state);
    let cleared = 0;
    for (const v of shared.vars || []) {
      if (isSecretVar(v.name) && v.value) {
        v.value = '';
        cleared += 1;
      }
    }
    downloadJson(exportState(shared));
    setSaveStatus(
      cleared
        ? `已导出分享版（清掉了 ${cleared} 个密钥值）`
        : '已导出分享版（没有发现要清的密钥值）'
    );
  });

  $('#btn-import').addEventListener('click', () => els.fileImport.click());

  els.fileImport.addEventListener('change', async () => {
    const file = els.fileImport.files && els.fileImport.files[0];
    els.fileImport.value = '';
    if (!file) return;

    try {
      const text = await file.text();

      

      let plainText = text;
      if (isEncryptedExport(text)) {
        const pass = await askPassphrase({
          title: '输入口令',
          note: '这份配置文件是加密导出的。'
        });
        if (!pass) return;
        try {
          plainText = await decryptExport(text, pass);
        } catch (err) {
          alert('导入失败：' + (err && err.message));
          return;
        }
      }

      
      const { exportedAt, ...parsed } = importState(plainText);
      if (!parsed.configs.length) {
        alert('导入失败：文件里没有配置');
        return;
      }

      

      const picked = await pickImportConfigs(parsed, exportedAt);
      if (!picked) return;   

      if (picked.merge) {
        

        const byName = new Map(state.configs.map((c) => [c.name, c]));
        for (const c of picked.configs) byName.set(c.name, c);
        state.configs = [...byName.values()];
        
        if (Array.isArray(state.slotConfigs)) {
          for (const c of picked.configs) {
            if (!state.slotConfigs.includes(c.id) && state.slotConfigs.length < 4) {
              state.slotConfigs.push(c.id);
            }
          }
        }
      } else {
        state = { ...state, ...parsed, configs: picked.configs };
      }

      editingId = state.activeConfigId = state.configs[0].id;
      editingOcrId = state.ocr.activeId;
      
      
      renderConfigList();
      renderEditor();
      renderOcrList();
      renderOcrEditor();
      renderVars();
      renderSettings();
      await persist();
      setSaveStatus(`导入完成（${state.configs.length} 条配置）`);
    } catch (err) {
      alert('导入失败：' + (err && err.message));
    }
  });
}



function scheduleSave() {
  clearTimeout(saveTimer);
  setSaveStatus('编辑中…');
  saveTimer = setTimeout(() => persist(), 700);
}

function flushEditor() {
  if (saveTimer) {
    clearTimeout(saveTimer);
    saveTimer = null;
    collectEditor();
    persist(false);
  }
}

async function persist(showStatus = true) {
  clearTimeout(saveTimer);
  saveTimer = null;
  
  collectEditor();
  collectOcrEditor();
  


  try {
    const saved = (await chrome.storage.local.get('state')).state;
    adoptPanelOwned(state, saved, panelTouched);
  } catch {
    
  }
  await saveState(state);
  if (showStatus) flashSaved();
}



function syncRestoreHints() {
  const b = document.querySelector('#btn-restore-hints');
  if (b) b.hidden = !(state.settings.hiddenHints || []).length;
}















function applyHintHides() {
  const hidden = new Set(state.settings.hiddenHints || []);

  for (const el of document.querySelectorAll('[data-hint]')) {
    if (!el.querySelector('.hint-hide')) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'hint-hide';
      b.textContent = T('opt_hint_dismiss', '不再显示');
      b.addEventListener('click', () => {
        const id = el.dataset.hint;
        state.settings.hiddenHints = [...new Set([...(state.settings.hiddenHints || []), id])];
        el.classList.add('hint-off');
        persist();
        syncRestoreHints();
      });
      el.appendChild(b);
    }
    el.classList.toggle('hint-off', hidden.has(el.dataset.hint));
  }
  syncRestoreHints();
}




function setSaveStatus(text, saved = false) {
  for (const el of document.querySelectorAll('.save-status')) {
    el.textContent = text;
    el.classList.toggle('saved', saved);
  }
}

let savedTimer = null;
function flashSaved() {
  const t = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  setSaveStatus(`已保存 ${pad(t.getHours())}:${pad(t.getMinutes())}:${pad(t.getSeconds())}`, true);
  clearTimeout(savedTimer);
  savedTimer = setTimeout(() => setSaveStatus(''), 2500);
}







const LANG_OTHER = '__other__';


function fillTargetLangOptions() {
  for (const name of TARGET_PRESETS) {
    els.langSelect.appendChild(newOption(name, name));
  }
  els.langSelect.appendChild(newOption(LANG_OTHER, '其他（自己填）'));
}

function newOption(value, text) {
  const opt = document.createElement('option');
  opt.value = value;
  opt.textContent = text;
  return opt;
}


function renderTargetLang() {
  const cur = String(state.settings.targetLang || '');
  if (cur && !TARGET_PRESETS.includes(cur)) {
    els.langSelect.value = LANG_OTHER;
    els.langOther.value = cur;
    els.langOther.hidden = false;
  } else {
    els.langSelect.value = cur || TARGET_PRESETS[0];
    els.langOther.hidden = true;
  }
}

function setTargetLang(value) {
  state.settings.targetLang = value;
  panelTouched.add('targetLang'); 
  scheduleSave();
  updatePreview();
}

function bindTargetLang() {
  els.langSelect.addEventListener('input', () => {
    if (els.langSelect.value === LANG_OTHER) {
      els.langOther.hidden = false;
      els.langOther.focus();
      
      
      const kept = els.langOther.value.trim();
      if (kept) setTargetLang(kept);
      return;
    }
    els.langOther.hidden = true;
    setTargetLang(els.langSelect.value);
  });

  els.langOther.addEventListener('input', () => {
    
    const v = els.langOther.value.trim();
    if (v) setTargetLang(v);
  });
}

window.addEventListener('beforeunload', () => {
  


  if (saveTimer) persist(false);
});
